import json
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import List

class DataNormalizer:
    """Normalize TXT/JSON/XML to unified format with EOS"""
    
    @staticmethod
    def load(path: str) -> List[str]:
        """Load and normalize data from any supported format"""
        suffix = Path(path).suffix.lower()
        loaders = {
            '.txt': DataNormalizer._load_txt,
            '.json': DataNormalizer._load_json,
            '.xml': DataNormalizer._load_xml
        }
        return loaders.get(suffix, DataNormalizer._load_txt)(path)
    
    @staticmethod
    def _load_txt(path: str) -> List[str]:
        with open(path, 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip()]
    
    @staticmethod
    def _load_json(path: str) -> List[str]:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            
        # Handle different JSON structures
        if isinstance(data, list):
            return [DataNormalizer._flatten_dict(item) if isinstance(item, dict) else str(item) 
                   for item in data]
        elif isinstance(data, dict):
            # Handle nested dict
            if all(isinstance(v, dict) for v in data.values()):
                return [DataNormalizer._flatten_dict(v) for v in data.values()]
            return [DataNormalizer._flatten_dict(data)]
        return [str(data)]
    
    @staticmethod
    def _load_xml(path: str) -> List[str]:
        tree = ET.parse(path)
        root = tree.getroot()
        return [DataNormalizer._xml_to_text(elem) for elem in root]
    
    @staticmethod
    def _flatten_dict(d: dict) -> str:
        """Flatten dict to readable text"""
        return ' '.join(f"{k}: {v}" for k, v in d.items() if v)
    
    @staticmethod
    def _xml_to_text(elem) -> str:
        """Convert XML element to text"""
        text = elem.text or ''
        for child in elem:
            text += f" {child.tag}: {child.text or ''}"
        return text.strip()
    
    @staticmethod
    def save_with_eos(texts: List[str], output_path: str, eos_token: str = "<|endoftext|>"):
        """Save normalized data with EOS tokens"""
        with open(output_path, 'w', encoding='utf-8') as f:
            f.writelines(f"{text}{eos_token}\n" for text in texts)
