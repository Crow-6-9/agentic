from typing import List
from transformers import AutoModelForMaskedLM, TrainingArguments, DataCollatorForLanguageModeling
from datasets import Dataset

from core.trainer import BaseTrainer

class MaskedLMTrainer(BaseTrainer):
    """Masked LM specific trainer (e.g. BERT)"""
    
    def _load_model(self):
        return AutoModelForMaskedLM.from_pretrained(
            self.config.model_path, 
            local_files_only=True
        )
    
    def _create_dataset(self, texts: List[str]) -> Dataset:
        tokenized = self.tokenizer(
            texts,
            truncation=True,
            padding='max_length',
            max_length=self.config.max_length,
            return_tensors='pt'
        )
        return Dataset.from_dict({
            'input_ids': tokenized['input_ids'],
            'attention_mask': tokenized['attention_mask']
        })
    
    def _get_training_args(self) -> TrainingArguments:
        return TrainingArguments(
            output_dir=self.output_dir,
            num_train_epochs=self.config.epochs,
            per_device_train_batch_size=self.config.batch_size,
            learning_rate=self.config.learning_rate,
            use_cpu=True,
            save_strategy="epoch",
            report_to="none",
            logging_steps=10
        )
    
    def _get_data_collator(self):
        return DataCollatorForLanguageModeling(
            tokenizer=self.tokenizer, 
            mlm=True,
            mlm_probability=0.15
        )
