from configs.parser import TrainingConfig
from core.trainer import BaseTrainer
from models.causal_lm import CausalLMTrainer
from models.seq2seq_lm import Seq2SeqTrainer
from models.masked_lm import MaskedLMTrainer

class TrainerFactory:
    """Factory pattern for trainer selection"""
    
    _trainers = {
        'text-generation': CausalLMTrainer,
        'text2text-generation': Seq2SeqTrainer,
        'fill-mask': MaskedLMTrainer,
        # Aliases just in case
        'causallm': CausalLMTrainer,
        'seq2seqlm': Seq2SeqTrainer,
        'maskedlm': MaskedLMTrainer
    }
    
    @classmethod
    def create(cls, config: TrainingConfig) -> BaseTrainer:
        trainer_cls = cls._trainers.get(config.architecture_tag.lower())
        if not trainer_cls:
            raise ValueError(f"Unsupported architecture tag: {config.architecture_tag}. We currently support text-generation, text2text-generation, and fill-mask.")
        return trainer_cls(config)
