import os
from dataclasses import dataclass
from typing import Optional

@dataclass
class TrainingConfig:
    """Immutable training configuration"""
    model: str
    architecture_tag: str
    model_path: str
    data_path: str
    epochs: int
    max_length: int
    batch_size: int
    learning_rate: float
    lora_r: Optional[int] = None
    lora_alpha: Optional[int] = None
    lora_dropout: Optional[float] = None
    
    @property
    def is_lora(self) -> bool: 
        return all(v is not None for v in [self.lora_r, self.lora_alpha, self.lora_dropout])
    
    @property
    def training_method(self) -> str: 
        return "lora" if self.is_lora else "traditional"

def parse_config_file(filepath: str, model: str, architecture_tag: str) -> TrainingConfig:
    """
    Parses a KEY=VALUE text file and returns a TrainingConfig object.
    
    Expected keys:
    model_path, data_path, epochs, max_length, batch_size, learning_rate
    Optional LoRA keys: lora_r, lora_alpha, lora_dropout
    """
    if not os.path.isfile(filepath):
        raise FileNotFoundError(f"Config file not found: {filepath}")

    config_dict = {}
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            # Ignore empty lines and comments
            if not line or line.startswith('#'):
                continue
            
            if '=' in line:
                key, val = line.split('=', 1)
                key = key.strip().lower()
                val = val.strip()
                if val.lower() in ('null', 'none', ''):
                    config_dict[key] = None
                else:
                    config_dict[key] = val

    # Validate required parameters
    required_keys = ['model_path', 'data_path', 'epochs']
    for k in required_keys:
        if k not in config_dict or config_dict[k] is None:
            raise ValueError(f"Missing required config key: {k}")

    # Build TrainingConfig with type conversions
    try:
        epochs = int(config_dict['epochs'])
        max_length = int(config_dict.get('max_length', 128))
        batch_size = int(config_dict.get('batch_size', 4))
        learning_rate = float(config_dict.get('learning_rate', 1e-5))

        lora_r = config_dict.get('lora_r')
        lora_r = int(lora_r) if lora_r is not None else None
        
        lora_alpha = config_dict.get('lora_alpha')
        lora_alpha = int(lora_alpha) if lora_alpha is not None else None

        lora_dropout = config_dict.get('lora_dropout')
        lora_dropout = float(lora_dropout) if lora_dropout is not None else None

        return TrainingConfig(
            model=model,
            architecture_tag=architecture_tag,
            model_path=config_dict['model_path'],
            data_path=config_dict['data_path'],
            epochs=epochs,
            max_length=max_length,
            batch_size=batch_size,
            learning_rate=learning_rate,
            lora_r=lora_r,
            lora_alpha=lora_alpha,
            lora_dropout=lora_dropout
        )
    except ValueError as e:
        raise ValueError(f"Error parsing config value types: {e}")
