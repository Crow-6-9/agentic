#!/usr/bin/env python3
import sys
import os

# Add current directory to path so modules can be imported if run directly
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from configs.parser import parse_config_file
from utils.data import DataNormalizer
from models.factory import TrainerFactory

def main():
    print("=" * 50)
    print("🤖 Automated Model Training System")
    print("=" * 50)
    
    import requests
    
    # Question 1: Model Choice
    model_choice = ""
    pipeline_tag = None
    while not pipeline_tag:
        model_choice = input("Which Hugging Face model do you want to train? (e.g., google/flan-t5-small, gpt2, bert-base-uncased): ").strip()
        
        print(f"🔍 Verifying model '{model_choice}' on Hugging Face...")
        try:
            response = requests.get(f"https://huggingface.co/api/models/{model_choice}")
            if response.status_code == 200:
                data = response.json()
                pipeline_tag = data.get("pipeline_tag")
                
                # Default mappings if missing but we know it exists
                if not pipeline_tag:
                    # In some cases HF missing tag, we might have to infer. For now assume text-generation if missing.
                    print("⚠️ Pipeline tag not found in Hugging Face API. Defaulting to 'text-generation'.")
                    pipeline_tag = "text-generation"
                
                print(f"✅ Model found! Architecture type identified as: {pipeline_tag}")
            else:
                print(f"❌ Invalid choice or model not found on Hugging Face. (HTTP {response.status_code})")
        except Exception as e:
            print(f"❌ Error connecting to Hugging Face API: {e}")
            print("Please ensure you have an active internet connection.")
            
    # Question 2: Config Path
    config_path = ""
    while not os.path.isfile(config_path):
        config_path = input("\nPlease share the path to your config.txt file: ").strip()
        # Remove quotes if user dragged and dropped
        if config_path.startswith('"') and config_path.endswith('"'):
            config_path = config_path[1:-1]
        if not os.path.isfile(config_path):
            print(f"File not found: {config_path}")
            
    try:
        # Load configs
        config = parse_config_file(config_path, model_choice, pipeline_tag)
        print(f"\n✅ Configurations loaded successfully.")
        print(f"🔧 Training Method: {config.training_method.upper()}")
        if config.is_lora:
            print(f"   LoRA R: {config.lora_r}, Alpha: {config.lora_alpha}, Dropout: {config.lora_dropout}")
        
        # Load dataset
        print(f"\n📂 Loading dataset from {config.data_path}...")
        texts = DataNormalizer.load(config.data_path)
        total_records = len(texts)
        print(f"📊 Found a total of {total_records} records.")
        
        # Question 3: Subset selection
        record_count = -1
        while record_count == -1:
            ans = input(f"\nHow many records do you want to train on? (Enter a number up to {total_records} or 'all'): ").strip().lower()
            if ans == 'all':
                record_count = total_records
            elif ans.isdigit():
                parsed = int(ans)
                if 1 <= parsed <= total_records:
                    record_count = parsed
                else:
                    print(f"Please enter a number between 1 and {total_records}.")
            else:
                print("Invalid input. Enter a number or 'all'.")
        
        # Subset data
        texts_subset = texts[:record_count]
        print(f"✅ Selecting {record_count} records for training.")
        
        # Proceed to train
        print("\n⚙️  Initializing Trainer...")
        trainer = TrainerFactory.create(config)
        trainer.train(texts_subset)
        
    except Exception as e:
        print(f"\n❌ An error occurred: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
