"""
Page 3 — Rankings
Shows every stored resume ranked by embedding score.
Displays all three scores (TF-IDF, Embedding, Hybrid) for analysis.
"""

import logging

import pandas as pd
import streamlit as st
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

from services.matcher     import fit_label, SIMILARITY_THRESHOLD
from services.vectorstore import get_all_resumes, get_stats

st.set_page_config(page_title="Rankings", page_icon="📊", layout="wide")
st.title("📊 Resume Rankings")
st.caption("All stored resumes · Ranked by **Embedding Score** · All three scores shown for analysis")

# ── DB status ─────────────────────────────────────────────────────────────────
stats = get_stats()
if stats["total"] == 0:
    st.warning(
        "⚠️ No resumes stored yet. "
        "Go to **📋 Matcher**, upload a JD and resumes first."
    )
    st.stop()

# ── Controls ──────────────────────────────────────────────────────────────────
col_ctrl1, col_ctrl2, col_ctrl3 = st.columns([2, 2, 1])

with col_ctrl1:
    sort_by = st.selectbox(
        "Sort by",
        options = ["Embedding Score", "Hybrid Score", "TF-IDF Score"],
        index   = 0,
    )

with col_ctrl2:
    filter_fit = st.multiselect(
        "Filter by Fit",
        options  = ["Strong", "Good", "Weak"],
        default  = ["Strong", "Good", "Weak"],
    )

with col_ctrl3:
    st.markdown("<br>", unsafe_allow_html=True)
    refresh = st.button("🔄 Refresh", use_container_width=True)

# ── Load data ─────────────────────────────────────────────────────────────────
with st.spinner("Loading from ChromaDB..."):
    resumes = get_all_resumes()

logger.info(f"Rankings page loaded — {len(resumes)} resume(s)")

if not resumes:
    st.info("No resumes found.")
    st.stop()

# ── Build dataframe ───────────────────────────────────────────────────────────
sort_col_map = {
    "Embedding Score": "embedding_score",
    "Hybrid Score":    "hybrid_score",
    "TF-IDF Score":    "tfidf_score",
}
sort_key = sort_col_map[sort_by]

sorted_resumes = sorted(resumes, key=lambda r: r[sort_key], reverse=True)

def _fit_badge(score: float) -> str:
    label = fit_label(score)
    return {"Strong": "🟢 Strong", "Good": "🟡 Good", "Weak": "🔴 Weak"}.get(label, label)

rows = []
for i, r in enumerate(sorted_resumes, 1):
    label = fit_label(r["hybrid_score"])
    if label not in filter_fit:
        continue
    rows.append({
        "Rank":      i,
        "Name":      r["name"],
        "Email":     r["email"],
        "File":      r["filename"],
        "TF-IDF":    round(r["tfidf_score"], 4),
        "Embedding": round(r["embedding_score"], 4),
        "Hybrid":    round(r["hybrid_score"], 4),
        "JD Match":  "✅" if r["matches_jd"] else "❌",
        "Fit":       _fit_badge(r["hybrid_score"]),
        "Uploaded":  r["uploaded_at"][:10] if r.get("uploaded_at") else "N/A",
    })

# ── Summary metrics ───────────────────────────────────────────────────────────
total     = len(resumes)
strong    = sum(1 for r in resumes if fit_label(r["hybrid_score"]) == "Strong")
good      = sum(1 for r in resumes if fit_label(r["hybrid_score"]) == "Good")
weak      = sum(1 for r in resumes if fit_label(r["hybrid_score"]) == "Weak")
matched   = sum(1 for r in resumes if r["matches_jd"])

m1, m2, m3, m4, m5 = st.columns(5)
m1.metric("Total Resumes",     total)
m2.metric("🟢 Strong",         strong)
m3.metric("🟡 Good",           good)
m4.metric("🔴 Weak",           weak)
m5.metric("✅ Matched JD",     matched)

st.divider()

# ── Main table ────────────────────────────────────────────────────────────────
if not rows:
    st.info("No resumes match the selected filters.")
    st.stop()

st.markdown(f"**{len(rows)}** resume(s) shown · sorted by **{sort_by}**")

st.dataframe(
    rows,
    use_container_width = True,
    hide_index          = True,
    column_config       = {
        "TF-IDF":    st.column_config.NumberColumn(
            "TF-IDF",
            help   = "Keyword overlap score (0–1)",
            format = "%.4f",
        ),
        "Embedding": st.column_config.NumberColumn(
            "Embedding",
            help   = "Semantic similarity score (0–1)  ← primary ranking",
            format = "%.4f",
        ),
        "Hybrid":    st.column_config.NumberColumn(
            "Hybrid",
            help   = f"Weighted blend (TF-IDF 40% + Embedding 60%) · threshold={SIMILARITY_THRESHOLD}",
            format = "%.4f",
        ),
    },
)

# ── Score distribution chart ──────────────────────────────────────────────────
st.divider()
st.subheader("Score Distribution")

df = pd.DataFrame(rows)

tab1, tab2, tab3 = st.tabs(["Embedding Score", "Hybrid Score", "TF-IDF Score"])

with tab1:
    st.bar_chart(
        df.set_index("Name")["Embedding"],
        use_container_width = True,
        color               = "#4f8bf9",
    )
with tab2:
    st.bar_chart(
        df.set_index("Name")["Hybrid"],
        use_container_width = True,
        color               = "#f97b4f",
    )
with tab3:
    st.bar_chart(
        df.set_index("Name")["TF-IDF"],
        use_container_width = True,
        color               = "#4ff9a0",
    )

st.caption(
    "_Ranked by Embedding Score by default — "
    "change the 'Sort by' dropdown above to compare against Hybrid or TF-IDF._"
)
