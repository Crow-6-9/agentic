import os
import streamlit as st
from dotenv import load_dotenv

load_dotenv()

from core.logging_config import setup_logging
setup_logging(level=os.getenv("LOG_LEVEL", "INFO"))

from services.vectorstore import get_stats

st.set_page_config(
    page_title = "JD Matcher",
    page_icon  = "🤖",
    layout     = "wide",
)

st.title("🤖 JD Matcher v2")
st.caption("Hybrid ATS resume scoring · ChromaDB semantic search")

st.markdown(
    """
    Welcome! Use the sidebar to navigate between the three tools.

    | Page | What it does |
    |------|-------------|
    | 📋 **Matcher** | Upload a Job Description + resumes → score and rank them |
    | 🔍 **Search** | Type a skill or query to search all stored resumes |
    | 📊 **Rankings** | Full table of every stored resume ranked by embedding score |
    """
)

st.divider()

stats = get_stats()
col1, col2, col3 = st.columns(3)
col1.metric("Resumes in DB", stats["total"])
col2.metric("Collection", stats["collection"])
col3.metric("DB Path", stats["path"])
