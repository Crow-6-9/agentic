# JD Matcher — Hybrid ATS Resume Scorer

Matches resumes against a Job Description using a **hybrid TF-IDF + Embedding** approach, just like real ATS systems.

```
jd_matcher/
├── backend/                 ← FastAPI REST API
│   ├── main.py              ← App entry point
│   ├── routers/
│   │   ├── jd.py            ← POST /api/jd/upload
│   │   └── resumes.py       ← POST /api/resumes/upload  |  GET /api/resumes/results
│   ├── services/
│   │   ├── parser.py        ← .docx text extraction + metadata (name, email)
│   │   ├── embedding.py     ← Embedding API client
│   │   └── matcher.py       ← TF-IDF, embedding & hybrid scoring logic
│   ├── models/
│   │   └── schemas.py       ← Pydantic request/response models
│   ├── store/
│   │   └── session.py       ← In-memory session store (swap for Redis in prod)
│   ├── .env.example
│   └── requirements.txt
│
├── frontend/                ← Chainlit chat UI (calls backend API)
│   ├── app.py
│   ├── .env.example
│   └── requirements.txt
│
└── README.md
```

---

## Quickstart

### 1 — Backend

```bash
cd backend
cp .env.example .env          # fill in API_KEY, EMBEDDING_MODEL, EMBEDDING_URL
pip install -r requirements.txt
uvicorn backend.main:app --reload --port 8000
```

Interactive API docs → http://localhost:8000/docs

### 2 — Frontend (Chainlit)

```bash
cd frontend
cp .env.example .env          # set BACKEND_URL=http://localhost:8000
pip install -r requirements.txt
chainlit run app.py
```

---

## API Reference

All endpoints accept/return JSON. Resumes and JD are uploaded as `multipart/form-data`.

### `POST /api/jd/upload`
Upload a Job Description (.docx). Returns a `session_id`.

| Header | Required | Description |
|--------|----------|-------------|
| `X-Session-Id` | No | Reuse an existing session (omit to create a new one) |

**Response**
```json
{
  "message": "Job Description processed successfully.",
  "session_id": "abc-123",
  "filename": "jd_backend_engineer.docx"
}
```

---

### `POST /api/resumes/upload`
Upload 1–10 resumes (.docx). Each is scored immediately.

| Header | Required | Description |
|--------|----------|-------------|
| `X-Session-Id` | ✅ Yes | Session from the JD upload step |

**Response**
```json
{
  "message": "3 resume(s) processed, 0 skipped.",
  "processed": 3,
  "skipped": 0,
  "results": [
    {
      "filename": "john_doe.docx",
      "metadata": { "name": "John Doe", "email": "john@example.com" },
      "tfidf_score": 0.4321,
      "embedding_score": 0.8123,
      "hybrid_score": 0.6610,
      "matches_jd": false,
      "fit_label": "Weak"
    }
  ]
}
```

---

### `GET /api/resumes/results`
Returns all resumes ranked by hybrid score.

| Header | Required |
|--------|----------|
| `X-Session-Id` | ✅ Yes |

**Response**
```json
{
  "session_id": "abc-123",
  "total": 5,
  "shortlisted": 3,
  "below_threshold": 2,
  "tfidf_weight": 0.4,
  "embedding_weight": 0.6,
  "threshold": 0.7,
  "ranked": [ ...ResumeResult objects... ]
}
```

---

## Scoring

| Method | What it measures | Weight |
|--------|-----------------|--------|
| TF-IDF | Exact keyword overlap between JD and resume | 40% |
| Embedding | Semantic similarity (synonyms, context) | 60% |
| **Hybrid** | Weighted blend — the final ATS score | — |

Fit labels: `Strong` (≥0.85) · `Good` (≥0.70) · `Weak` (<0.70)

Tune weights in `backend/services/matcher.py`.

---

## For Frontend Developers

The backend is a plain REST API — no Chainlit dependency. Any frontend (React, Vue, mobile) can:

1. `POST /api/jd/upload` → save the returned `session_id`
2. `POST /api/resumes/upload` (with `X-Session-Id`) → show per-resume scores
3. `GET /api/resumes/results` (with `X-Session-Id`) → render the ranked table

The Chainlit `frontend/app.py` is just one possible UI on top of this API.
