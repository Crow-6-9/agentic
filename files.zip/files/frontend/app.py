"""
JD Matcher — Chainlit Frontend
Calls the FastAPI backend via HTTP.  No matching logic lives here.
"""
import os
import httpx
import chainlit as cl
from dotenv import load_dotenv

load_dotenv()

BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000")


# ─────────────────────────────────────────────
# API HELPERS
# ─────────────────────────────────────────────

async def api_upload_jd(file_path: str, filename: str, session_id: str | None = None):
    headers = {}
    if session_id:
        headers["X-Session-Id"] = session_id

    async with httpx.AsyncClient(timeout=60) as client:
        with open(file_path, "rb") as f:
            response = await client.post(
                f"{BACKEND_URL}/api/jd/upload",
                headers=headers,
                files={"file": (filename, f, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")},
            )
    response.raise_for_status()
    return response.json()


async def api_upload_resumes(file_paths: list[tuple[str, str]], session_id: str):
    """Upload multiple resume files. file_paths = [(path, filename), ...]"""
    headers = {"X-Session-Id": session_id}

    files = []
    file_handles = []
    try:
        for path, name in file_paths:
            fh = open(path, "rb")
            file_handles.append(fh)
            files.append(("files", (name, fh, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")))

        async with httpx.AsyncClient(timeout=120) as client:
            response = await client.post(
                f"{BACKEND_URL}/api/resumes/upload",
                headers=headers,
                files=files,
            )
        response.raise_for_status()
        return response.json()
    finally:
        for fh in file_handles:
            fh.close()


async def api_get_results(session_id: str):
    headers = {"X-Session-Id": session_id}
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.get(f"{BACKEND_URL}/api/resumes/results", headers=headers)
    response.raise_for_status()
    return response.json()


# ─────────────────────────────────────────────
# UI HELPERS
# ─────────────────────────────────────────────

def fit_emoji(label: str) -> str:
    return {"Strong": "🟢", "Good": "🟡", "Weak": "🔴"}.get(label, "⚪")


def build_results_table(ranked: list) -> str:
    header = (
        "| Rank | Name | Email | TF-IDF | Embedding | Hybrid | Fit |\n"
        "|:----:|------|-------|:------:|:---------:|:------:|:---:|\n"
    )
    rows = ""
    for i, r in enumerate(ranked, 1):
        emoji = fit_emoji(r["fit_label"])
        rows += (
            f"| {i} "
            f"| {r['metadata']['name']} "
            f"| {r['metadata']['email']} "
            f"| {r['tfidf_score']:.4f} "
            f"| {r['embedding_score']:.4f} "
            f"| {r['hybrid_score']:.4f} "
            f"| {emoji} {r['fit_label']} |\n"
        )
    return header + rows


# ─────────────────────────────────────────────
# GUIDED FLOW
# ─────────────────────────────────────────────

async def step_upload_jd():
    files = await cl.AskFileMessage(
        content=(
            "### 📋 Step 1 of 3 — Upload Job Description\n"
            "Upload the Job Description as a **.docx** file."
        ),
        accept=["application/vnd.openxmlformats-officedocument.wordprocessingml.document"],
        max_files=1,
        raise_on_timeout=False,
    ).send()

    if not files:
        await cl.Message(content="⚠️ No file received. Refresh and try again.").send()
        return

    file = files[0]
    processing = await cl.Message(content=f"⏳ Processing **{file.name}**...").send()

    try:
        data = await api_upload_jd(file.path, file.name)
    except httpx.HTTPStatusError as e:
        detail = e.response.json().get("detail", str(e))
        await cl.Message(content=f"❌ Backend error: {detail}").send()
        return
    except Exception as e:
        await cl.Message(content=f"❌ Could not reach the backend: {e}\n\nMake sure the API server is running at `{BACKEND_URL}`.").send()
        return

    session_id = data["session_id"]
    cl.user_session.set("session_id", session_id)
    await cl.Message(content=f"✅ **Job Description loaded:** {file.name}\n> Session ID: `{session_id}`").send()
    await step_upload_resumes()


async def step_upload_resumes():
    files = await cl.AskFileMessage(
        content=(
            "### 📂 Step 2 of 3 — Upload Resumes\n"
            "Upload up to **10 resumes** (.docx). They'll be scored immediately."
        ),
        accept=["application/vnd.openxmlformats-officedocument.wordprocessingml.document"],
        max_files=10,
        raise_on_timeout=False,
    ).send()

    if not files:
        await cl.Message(content="⚠️ No resumes received.").send()
        return

    session_id = cl.user_session.get("session_id")
    if not session_id:
        await cl.Message(content="⚠️ Session lost. Please restart and upload the JD first.").send()
        return

    await cl.Message(content=f"⏳ Sending **{len(files)}** resume(s) to the matcher...").send()

    file_paths = [(f.path, f.name) for f in files]

    try:
        data = await api_upload_resumes(file_paths, session_id)
    except httpx.HTTPStatusError as e:
        detail = e.response.json().get("detail", str(e))
        await cl.Message(content=f"❌ Backend error: {detail}").send()
        return
    except Exception as e:
        await cl.Message(content=f"❌ Could not reach the backend: {e}").send()
        return

    # Show individual resume results as they come back
    for r in data["results"]:
        emoji = fit_emoji(r["fit_label"])
        await cl.Message(
            content=(
                f"📄 **{r['filename']}**\n"
                f"> 👤 {r['metadata']['name']}  ·  📧 {r['metadata']['email']}\n"
                f"> TF-IDF: `{r['tfidf_score']:.4f}` · Embedding: `{r['embedding_score']:.4f}` "
                f"· Hybrid: `{r['hybrid_score']:.4f}`  {emoji} **{r['fit_label']}**"
            )
        ).send()

    if data["skipped"] > 0:
        await cl.Message(content=f"⚠️ {data['skipped']} file(s) were skipped (non-.docx or embedding failure).").send()

    await step_show_results()


async def step_show_results():
    session_id = cl.user_session.get("session_id")
    if not session_id:
        await cl.Message(content="⚠️ No active session found.").send()
        return

    try:
        data = await api_get_results(session_id)
    except httpx.HTTPStatusError as e:
        detail = e.response.json().get("detail", str(e))
        await cl.Message(content=f"❌ Could not fetch results: {detail}").send()
        return

    table = build_results_table(data["ranked"])
    tw = int(data["tfidf_weight"] * 100)
    ew = int(data["embedding_weight"] * 100)

    await cl.Message(
        content=(
            "### 🏆 Step 3 of 3 — Ranked Results\n\n"
            f"**Scoring:** TF-IDF `{tw}%` + Embedding `{ew}%`  ·  "
            f"**Threshold:** `{data['threshold']}`\n\n"
            f"{table}\n\n"
            f"**Summary:** 🟢/🟡 `{data['shortlisted']}` shortlisted  ·  "
            f"🔴 `{data['below_threshold']}` below threshold\n\n"
            "_TF-IDF = keyword overlap · Embedding = semantic similarity · Hybrid = weighted blend_"
        )
    ).send()

    await cl.Message(
        content=(
            "**What next?**\n"
            "- Say **`more resumes`** — upload more resumes against the same JD\n"
            "- Say **`show results`** — re-display the rankings\n"
            "- Say **`restart`** — start over with a new Job Description"
        )
    ).send()


# ─────────────────────────────────────────────
# CHAINLIT ENTRY POINTS
# ─────────────────────────────────────────────

@cl.on_chat_start
async def start():
    cl.user_session.set("session_id", None)

    await cl.Message(
        content=(
            "# 🤖 ATS Resume Matcher\n"
            "Hybrid scoring: **TF-IDF** (keyword overlap) + **Embeddings** (semantic meaning).\n\n"
            "Let's get started! 👇"
        )
    ).send()

    await step_upload_jd()


@cl.on_message
async def on_message(message: cl.Message):
    text = message.content.strip().lower()

    if any(k in text for k in ["more resumes", "upload more", "add resumes"]):
        session_id = cl.user_session.get("session_id")
        if not session_id:
            await cl.Message(content="⚠️ No JD loaded. Say **restart** to begin again.").send()
        else:
            await step_upload_resumes()

    elif any(k in text for k in ["restart", "reset", "new jd", "start over"]):
        cl.user_session.set("session_id", None)
        await cl.Message(content="🔄 Starting fresh...").send()
        await step_upload_jd()

    elif any(k in text for k in ["result", "rank", "show", "table"]):
        await step_show_results()

    else:
        await cl.Message(
            content=(
                "I didn't catch that. You can say:\n"
                "- **`more resumes`** — upload more resumes against the current JD\n"
                "- **`show results`** — re-display the rankings\n"
                "- **`restart`** — start over with a new JD"
            )
        ).send()
