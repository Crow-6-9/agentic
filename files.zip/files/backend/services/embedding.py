import os
import logging
import requests
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

API_KEY         = os.getenv("API_KEY")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL")
EMBEDDING_URL   = os.getenv("EMBEDDING_URL", "")   # your embedding endpoint


def get_embedding(text: str) -> list | None:
    """
    Call the configured embedding API and return the embedding vector.
    Returns None on failure so callers can decide how to handle it.
    """
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {"input": text, "model": EMBEDDING_MODEL}

    try:
        response = requests.post(EMBEDDING_URL, headers=headers, json=payload, timeout=30)
        response.raise_for_status()
        return response.json()["data"][0]["embedding"]
    except Exception as err:
        logger.error(f"Embedding API error: {err}")
        return None
