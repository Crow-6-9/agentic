import re
import logging
from docx import Document

logger = logging.getLogger(__name__)


def extract_text_from_docx(file_path: str) -> str:
    """Extract clean text from a .docx file."""
    doc = Document(file_path)
    return "\n".join([p.text for p in doc.paragraphs if p.text.strip()])


def extract_metadata(text: str) -> dict:
    """
    Extract candidate name and email from resume text.

    Email  → reliable regex match against the full text.
    Name   → first non-empty line heuristic. Most resumes open with
             the candidate's full name. Falls back to "Unknown" if
             the line doesn't look like a human name.
    """
    # ── Email ──────────────────────────────────────────────────────────────
    email_match = re.search(
        r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}",
        text,
    )
    email = email_match.group(0) if email_match else "N/A"

    # ── Name ───────────────────────────────────────────────────────────────
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    raw_name = lines[0] if lines else "Unknown"

    # Validate: only letters, spaces, hyphens, apostrophes; 2–50 chars
    name = raw_name if re.match(r"^[A-Za-z .'\-]{2,50}$", raw_name) else "Unknown"

    return {"name": name, "email": email}
