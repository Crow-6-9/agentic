import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.routers import jd, resumes

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)

app = FastAPI(
    title="JD Matcher API",
    description=(
        "Hybrid ATS resume matching API using **TF-IDF** (keyword overlap) "
        "+ **Embeddings** (semantic similarity).\n\n"
        "### Typical flow\n"
        "1. `POST /api/jd/upload` → get a `session_id`\n"
        "2. `POST /api/resumes/upload` (with `X-Session-Id`) → upload & score resumes\n"
        "3. `GET /api/resumes/results` (with `X-Session-Id`) → ranked leaderboard"
    ),
    version="1.0.0",
)

# ── CORS ─────────────────────────────────────────────────────────────────────
# Allow all origins in dev; tighten this in production.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(jd.router)
app.include_router(resumes.router)


@app.get("/", tags=["Health"])
async def root():
    return {
        "status": "ok",
        "message": "JD Matcher API is running. Visit /docs for the interactive API explorer.",
    }


@app.get("/health", tags=["Health"])
async def health():
    return {"status": "healthy"}
