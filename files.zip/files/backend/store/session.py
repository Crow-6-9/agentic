"""
Simple in-memory store keyed by session_id.
In production replace with Redis or a database.
"""
from typing import Optional
import threading

_lock = threading.Lock()

_store: dict[str, dict] = {}


def create_session(session_id: str) -> None:
    with _lock:
        _store[session_id] = {"jd": None, "jd_embedding": None, "resumes": []}


def get_session(session_id: str) -> Optional[dict]:
    return _store.get(session_id)


def set_jd(session_id: str, jd_text: str, jd_embedding: list) -> None:
    with _lock:
        if session_id not in _store:
            create_session(session_id)
        _store[session_id]["jd"] = jd_text
        _store[session_id]["jd_embedding"] = jd_embedding


def append_resume(session_id: str, resume: dict) -> None:
    with _lock:
        _store[session_id]["resumes"].append(resume)


def get_resumes(session_id: str) -> list:
    session = _store.get(session_id)
    return session["resumes"] if session else []


def get_jd(session_id: str) -> Optional[str]:
    session = _store.get(session_id)
    return session["jd"] if session else None


def get_jd_embedding(session_id: str) -> Optional[list]:
    session = _store.get(session_id)
    return session["jd_embedding"] if session else None


def clear_session(session_id: str) -> None:
    with _lock:
        _store.pop(session_id, None)
