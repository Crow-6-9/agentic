import tempfile
import os
import logging
from typing import List

from fastapi import APIRouter, UploadFile, File, HTTPException, Header

from backend.services.parser import extract_text_from_docx, extract_metadata
from backend.services.embedding import get_embedding
from backend.services.matcher import (
    compute_tfidf_score,
    compute_embedding_score,
    compute_hybrid_score,
    fit_label,
    is_match,
    TFIDF_WEIGHT,
    EMBEDDING_WEIGHT,
    SIMILARITY_THRESHOLD,
)
from backend.store import session as store
from backend.models.schemas import (
    ResumeResult,
    ResumeMetadata,
    ResumeUploadResponse,
    RankedResultsResponse,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/resumes", tags=["Resumes"])


def _require_session(session_id: str | None) -> dict:
    """Validate session exists and has a JD loaded."""
    if not session_id:
        raise HTTPException(status_code=400, detail="X-Session-Id header is required.")
    session = store.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found. Upload a JD first.")
    if not session.get("jd_embedding"):
        raise HTTPException(status_code=400, detail="No Job Description found for this session. Upload one via POST /api/jd/upload.")
    return session


@router.post(
    "/upload",
    response_model=ResumeUploadResponse,
    summary="Upload resumes and score them against the loaded JD",
)
async def upload_resumes(
    files: List[UploadFile] = File(..., description="One or more .docx resume files (max 10)"),
    x_session_id: str | None = Header(default=None),
):
    """
    Upload up to 10 resumes (.docx).  
    Each resume is scored with **TF-IDF**, **Embedding**, and a **Hybrid** (weighted blend) approach.  
    Results are stored in the session and also returned immediately.

    Requires `X-Session-Id` from a previous `POST /api/jd/upload` call.
    """
    session = _require_session(x_session_id)

    if len(files) > 10:
        raise HTTPException(status_code=400, detail="Maximum 10 resumes per request.")

    jd_text      = session["jd"]
    jd_embedding = session["jd_embedding"]

    results: list[ResumeResult] = []
    skipped = 0

    for file in files:
        if not file.filename.endswith(".docx"):
            logger.warning(f"Skipped non-docx file: {file.filename}")
            skipped += 1
            continue

        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".docx") as tmp:
                tmp.write(await file.read())
                tmp_path = tmp.name

            resume_text = extract_text_from_docx(tmp_path)
        except Exception as e:
            logger.error(f"Parse error for {file.filename}: {e}")
            skipped += 1
            continue
        finally:
            os.unlink(tmp_path)

        metadata         = extract_metadata(resume_text)
        resume_embedding = get_embedding(resume_text)

        if resume_embedding is None:
            logger.warning(f"Embedding failed for {file.filename}, skipping.")
            skipped += 1
            continue

        tfidf_score     = compute_tfidf_score(jd_text, resume_text)
        embedding_score = compute_embedding_score(jd_embedding, resume_embedding)
        hybrid_score    = compute_hybrid_score(tfidf_score, embedding_score)

        result = ResumeResult(
            filename        = file.filename,
            metadata        = ResumeMetadata(**metadata),
            tfidf_score     = round(tfidf_score, 4),
            embedding_score = round(embedding_score, 4),
            hybrid_score    = hybrid_score,
            matches_jd      = is_match(hybrid_score),
            fit_label       = fit_label(hybrid_score),
        )
        results.append(result)
        store.append_resume(x_session_id, result.model_dump())

    return ResumeUploadResponse(
        message   = f"{len(results)} resume(s) processed, {skipped} skipped.",
        processed = len(results),
        skipped   = skipped,
        results   = results,
    )


@router.get(
    "/results",
    response_model=RankedResultsResponse,
    summary="Get ranked results for all resumes in a session",
)
async def get_results(
    x_session_id: str | None = Header(default=None),
):
    """
    Returns all resumes for the session ranked by **Hybrid Score** (descending).  
    Call this after one or more `POST /api/resumes/upload` calls.
    """
    _require_session(x_session_id)
    resumes = store.get_resumes(x_session_id)

    if not resumes:
        raise HTTPException(status_code=404, detail="No resumes found for this session. Upload resumes first.")

    ranked = sorted(resumes, key=lambda r: r["hybrid_score"], reverse=True)
    shortlisted = sum(1 for r in ranked if r["matches_jd"])

    return RankedResultsResponse(
        session_id       = x_session_id,
        total            = len(ranked),
        shortlisted      = shortlisted,
        below_threshold  = len(ranked) - shortlisted,
        tfidf_weight     = TFIDF_WEIGHT,
        embedding_weight = EMBEDDING_WEIGHT,
        threshold        = SIMILARITY_THRESHOLD,
        ranked           = [ResumeResult(**r) for r in ranked],
    )
