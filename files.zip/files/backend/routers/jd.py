import uuid
import tempfile
import os
import logging

from fastapi import APIRouter, UploadFile, File, HTTPException, Header
from fastapi.responses import JSONResponse

from backend.services.parser import extract_text_from_docx
from backend.services.embedding import get_embedding
from backend.store import session as store
from backend.models.schemas import JDUploadResponse

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/jd", tags=["Job Description"])


@router.post("/upload", response_model=JDUploadResponse, summary="Upload and embed a Job Description")
async def upload_jd(
    file: UploadFile = File(..., description="Job Description as a .docx file"),
    x_session_id: str | None = Header(default=None, description="Reuse an existing session, or omit to create a new one"),
):
    """
    Upload a Job Description (.docx).  
    Returns a `session_id` that must be passed in subsequent resume upload calls
    via the `X-Session-Id` header.
    """
    if not file.filename.endswith(".docx"):
        raise HTTPException(status_code=400, detail="Only .docx files are accepted.")

    # Create or reuse session
    session_id = x_session_id or str(uuid.uuid4())
    store.create_session(session_id)

    # Save to a temp file so python-docx can read it
    try:
        suffix = ".docx"
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp.write(await file.read())
            tmp_path = tmp.name

        jd_text = extract_text_from_docx(tmp_path)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to parse document: {e}")
    finally:
        os.unlink(tmp_path)

    jd_embedding = get_embedding(jd_text)
    if jd_embedding is None:
        raise HTTPException(status_code=502, detail="Embedding API failed. Check API_KEY and EMBEDDING_URL.")

    store.set_jd(session_id, jd_text, jd_embedding)
    logger.info(f"JD uploaded for session {session_id}: {file.filename}")

    return JDUploadResponse(
        message="Job Description processed successfully.",
        session_id=session_id,
        filename=file.filename,
    )
