from pydantic import BaseModel
from typing import Optional


class ResumeMetadata(BaseModel):
    name: str
    email: str


class ResumeResult(BaseModel):
    filename: str
    metadata: ResumeMetadata
    tfidf_score: float
    embedding_score: float
    hybrid_score: float
    matches_jd: bool
    fit_label: str


class JDUploadResponse(BaseModel):
    message: str
    session_id: str
    filename: str


class ResumeUploadResponse(BaseModel):
    message: str
    processed: int
    skipped: int
    results: list[ResumeResult]


class RankedResultsResponse(BaseModel):
    session_id: str
    total: int
    shortlisted: int
    below_threshold: int
    tfidf_weight: float
    embedding_weight: float
    threshold: float
    ranked: list[ResumeResult]


class ErrorResponse(BaseModel):
    detail: str
