"""
vectorstore.py — ChromaDB service for resume storage and retrieval.

Design:
  - One resume = one document (one chunk) in the collection.
  - The full resume text is the document content.
  - Pre-computed embeddings are injected directly — no re-embedding by Chroma.
  - Metadata makes every record self-contained for recruiter queries.

Collection schema:
  id         → "{email}__{filename}"  (email = unique person identifier)
  document   → full resume text
  embedding  → vector from your embedding API
  metadata   → name, email, filename, tfidf_score, embedding_score,
               hybrid_score, matches_jd, session_id, uploaded_at
"""

import os
import re
import logging
from datetime import datetime, timezone

import chromadb
from chromadb.config import Settings

logger = logging.getLogger(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
CHROMA_PATH       = os.getenv("CHROMA_PATH", "./chroma_db")
COLLECTION_NAME   = "resumes"

# ── Singleton client & collection ─────────────────────────────────────────────
_client: chromadb.PersistentClient | None = None
_collection = None


def _get_collection():
    global _client, _collection
    if _collection is None:
        logger.info(f"Initialising ChromaDB at: {CHROMA_PATH}")
        _client = chromadb.PersistentClient(path=CHROMA_PATH)
        _collection = _client.get_or_create_collection(
            name=COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},   # cosine distance for similarity
        )
        logger.info(
            f"ChromaDB ready — collection '{COLLECTION_NAME}' "
            f"has {_collection.count()} document(s)"
        )
    return _collection


def _make_doc_id(email: str, filename: str) -> str:
    """
    Build a stable, unique document ID.
    Email is the true unique key per person; filename scopes it to this upload.
    Sanitise to keep only safe characters.
    """
    safe_email    = re.sub(r"[^a-zA-Z0-9._\-]", "_", email)
    safe_filename = re.sub(r"[^a-zA-Z0-9._\-]", "_", filename)
    return f"{safe_email}__{safe_filename}"


# ── Public API ────────────────────────────────────────────────────────────────

def add_resume(
    *,
    text: str,
    embedding: list[float],
    name: str,
    email: str,
    filename: str,
    tfidf_score: float,
    embedding_score: float,
    hybrid_score: float,
    matches_jd: bool,
    session_id: str,
) -> str:
    """
    Upsert one resume into ChromaDB.
    Returns the doc_id used so callers can log or display it.
    """
    collection = _get_collection()
    doc_id     = _make_doc_id(email, filename)

    metadata = {
        "name":            name,
        "email":           email,
        "filename":        filename,
        "tfidf_score":     round(tfidf_score, 4),
        "embedding_score": round(embedding_score, 4),
        "hybrid_score":    round(hybrid_score, 4),
        "matches_jd":      1 if matches_jd else 0,   # Chroma stores bool as int
        "session_id":      session_id,
        "uploaded_at":     datetime.now(timezone.utc).isoformat(),
    }

    collection.upsert(
        ids        = [doc_id],
        documents  = [text],
        embeddings = [embedding],
        metadatas  = [metadata],
    )
    logger.info(f"Stored resume in ChromaDB — id='{doc_id}' name='{name}' email='{email}'")
    return doc_id


def query_resumes(
    query_embedding: list[float],
    n_results: int = 5,
    only_matched: bool = False,
) -> list[dict]:
    """
    Semantic search over stored resumes.
    Returns a list of candidate dicts sorted by relevance (closest first).

    Args:
        query_embedding: embedding of the recruiter's search query.
        n_results:       max candidates to return.
        only_matched:    if True, filter to resumes that passed the JD threshold.
    """
    collection = _get_collection()
    total      = collection.count()

    if total == 0:
        logger.warning("ChromaDB collection is empty — no resumes stored yet.")
        return []

    where = {"matches_jd": 1} if only_matched else None
    fetch = min(n_results, total)

    try:
        results = collection.query(
            query_embeddings = [query_embedding],
            n_results        = fetch,
            where            = where,
            include          = ["documents", "metadatas", "distances"],
        )
    except Exception as err:
        logger.error(f"ChromaDB query failed: {err}")
        return []

    candidates = []
    ids        = results["ids"][0]
    metadatas  = results["metadatas"][0]
    distances  = results["distances"][0]

    for doc_id, meta, dist in zip(ids, metadatas, distances):
        # Chroma cosine distance → similarity: 1 - distance
        search_similarity = round(1 - dist, 4)
        candidates.append({
            "doc_id":           doc_id,
            "name":             meta.get("name", "Unknown"),
            "email":            meta.get("email", "N/A"),
            "filename":         meta.get("filename", ""),
            "tfidf_score":      meta.get("tfidf_score", 0.0),
            "embedding_score":  meta.get("embedding_score", 0.0),
            "hybrid_score":     meta.get("hybrid_score", 0.0),
            "matches_jd":       bool(meta.get("matches_jd", 0)),
            "search_similarity": search_similarity,
            "uploaded_at":      meta.get("uploaded_at", ""),
        })

    logger.info(f"ChromaDB query returned {len(candidates)} candidate(s)")
    return candidates


def get_collection_stats() -> dict:
    """Return basic stats about the stored resume collection."""
    collection = _get_collection()
    total      = collection.count()
    return {"total_resumes": total, "collection": COLLECTION_NAME, "path": CHROMA_PATH}


def delete_resume(email: str, filename: str) -> bool:
    """Delete a specific resume by email + filename."""
    collection = _get_collection()
    doc_id     = _make_doc_id(email, filename)
    try:
        collection.delete(ids=[doc_id])
        logger.info(f"Deleted resume from ChromaDB — id='{doc_id}'")
        return True
    except Exception as err:
        logger.error(f"Failed to delete resume '{doc_id}': {err}")
        return False
