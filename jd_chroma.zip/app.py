"""
frontend/app.py — JD Matcher Chainlit UI

Two Chat Profiles:
  📋 Resume Matcher   — upload JD + resumes, compute hybrid scores, store to ChromaDB
  🔍 Recruiter Search — natural-language chat to query stored resumes from ChromaDB

Run from project root:
    chainlit run frontend/app.py --port 8001
"""

import os
import sys
import uuid
import logging

# ── Make sure backend package is importable when running from project root ────
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import chainlit as cl
from dotenv import load_dotenv

load_dotenv()

# ── Logging must be set up before any backend imports ─────────────────────────
from backend.core.logging_config import setup_logging
setup_logging(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger(__name__)

# ── Backend services (direct Python imports — no HTTP, no new API) ────────────
from backend.services.parser import extract_text_from_docx, extract_metadata
from backend.services.embedding import get_embedding
from backend.services.matcher import (
    compute_tfidf_score,
    compute_embedding_score,
    compute_hybrid_score,
    fit_label,
    is_match,
    TFIDF_WEIGHT,
    EMBEDDING_WEIGHT,
    SIMILARITY_THRESHOLD,
)
from backend.services.vectorstore import (
    add_resume,
    query_resumes,
    get_collection_stats,
)


# ════════════════════════════════════════════════════════════════════════════════
# CHAT PROFILES
# ════════════════════════════════════════════════════════════════════════════════

@cl.set_chat_profiles
async def chat_profile():
    return [
        cl.ChatProfile(
            name="📋 Resume Matcher",
            markdown_description=(
                "**Upload a Job Description and resumes.**\n\n"
                "Scores each resume with TF-IDF + Embedding hybrid scoring "
                "and stores results in the vector database for later querying."
            ),
        ),
        cl.ChatProfile(
            name="🔍 Recruiter Search",
            markdown_description=(
                "**Search stored resumes using natural language.**\n\n"
                "Ask things like *'find me a LangChain developer'* or "
                "*'who has React and Node experience?'* — powered by ChromaDB."
            ),
        ),
    ]


# ════════════════════════════════════════════════════════════════════════════════
# UI HELPERS
# ════════════════════════════════════════════════════════════════════════════════

def _fit_emoji(label: str) -> str:
    return {"Strong": "🟢", "Good": "🟡", "Weak": "🔴"}.get(label, "⚪")


def _build_results_table(sorted_resumes: list) -> str:
    header = (
        "| Rank | Name | Email | TF-IDF | Embedding | Hybrid | Fit |\n"
        "|:----:|------|-------|:------:|:---------:|:------:|:---:|\n"
    )
    rows = ""
    for i, r in enumerate(sorted_resumes, 1):
        label = fit_label(r["hybrid_score"])
        rows += (
            f"| {i} "
            f"| {r['metadata']['name']} "
            f"| {r['metadata']['email']} "
            f"| {r['tfidf_score']:.4f} "
            f"| {r['embedding_score']:.4f} "
            f"| {r['hybrid_score']:.4f} "
            f"| {_fit_emoji(label)} {label} |\n"
        )
    return header + rows


def _build_search_table(candidates: list) -> str:
    if not candidates:
        return "_No matching candidates found._"
    header = (
        "| Rank | Name | Email | Query Match | JD Hybrid | JD Fit |\n"
        "|:----:|------|-------|:-----------:|:---------:|:------:|\n"
    )
    rows = ""
    for i, c in enumerate(candidates, 1):
        jd_label = fit_label(c["hybrid_score"])
        rows += (
            f"| {i} "
            f"| {c['name']} "
            f"| {c['email']} "
            f"| `{c['search_similarity']:.4f}` "
            f"| `{c['hybrid_score']:.4f}` "
            f"| {_fit_emoji(jd_label)} {jd_label} |\n"
        )
    return header + rows


# ════════════════════════════════════════════════════════════════════════════════
# PROFILE 1 — RESUME MATCHER (3-step guided flow)
# ════════════════════════════════════════════════════════════════════════════════

async def step_upload_jd():
    """Step 1 — Upload and embed the Job Description."""
    logger.info("Matcher flow: waiting for JD upload")

    files = await cl.AskFileMessage(
        content=(
            "### 📋 Step 1 of 3 — Upload Job Description\n"
            "Upload the Job Description as a **.docx** file to get started."
        ),
        accept=["application/vnd.openxmlformats-officedocument.wordprocessingml.document"],
        max_files=1,
        raise_on_timeout=False,
    ).send()

    if not files:
        await cl.Message(content="⚠️ No file received. Refresh and try again.").send()
        return

    file = files[0]
    await cl.Message(content=f"⏳ Embedding **{file.name}**...").send()

    try:
        jd_text = extract_text_from_docx(file.path)
    except Exception as e:
        logger.error(f"Failed to parse JD {file.name}: {e}")
        await cl.Message(content=f"❌ Could not read the file: {e}").send()
        return

    jd_embedding = get_embedding(jd_text)
    if not jd_embedding:
        logger.error(f"Embedding failed for JD: {file.name}")
        await cl.Message(
            content="❌ Could not generate embedding. Check `API_KEY` and `EMBEDDING_URL` in your `.env`."
        ).send()
        return

    session_id = str(uuid.uuid4())
    cl.user_session.set("session_id",   session_id)
    cl.user_session.set("jd",           jd_text)
    cl.user_session.set("jd_embedding", jd_embedding)
    cl.user_session.set("resumes",      [])

    logger.info(f"JD loaded — session={session_id}  file={file.name}")
    await cl.Message(
        content=f"✅ **Job Description loaded:** {file.name}\n> Session: `{session_id}`"
    ).send()
    await step_upload_resumes()


async def step_upload_resumes():
    """Step 2 — Upload resumes, score each, store as one chunk in ChromaDB."""
    logger.info("Matcher flow: waiting for resume uploads")

    files = await cl.AskFileMessage(
        content=(
            "### 📂 Step 2 of 3 — Upload Resumes\n"
            "Upload up to **10 resumes** (.docx). Each resume is scored and stored "
            "as a single chunk in the vector database — one resume, one chunk."
        ),
        accept=["application/vnd.openxmlformats-officedocument.wordprocessingml.document"],
        max_files=10,
        raise_on_timeout=False,
    ).send()

    if not files:
        await cl.Message(content="⚠️ No resumes received.").send()
        return

    jd_text      = cl.user_session.get("jd")
    jd_embedding = cl.user_session.get("jd_embedding")
    session_id   = cl.user_session.get("session_id")
    resumes      = cl.user_session.get("resumes") or []

    await cl.Message(content=f"⏳ Processing **{len(files)}** resume(s)...").send()
    skipped = 0

    for file in files:
        logger.info(f"Processing: {file.name}")

        # ── Parse ─────────────────────────────────────────────────────────────
        try:
            resume_text = extract_text_from_docx(file.path)
        except Exception as e:
            logger.error(f"Parse error for {file.name}: {e}")
            await cl.Message(content=f"⚠️ Skipped **{file.name}** — could not read file.").send()
            skipped += 1
            continue

        # ── Extract metadata (name from first line, email from regex) ─────────
        metadata         = extract_metadata(resume_text)
        resume_embedding = get_embedding(resume_text)

        if not resume_embedding:
            logger.warning(f"Embedding failed: {file.name}")
            await cl.Message(content=f"⚠️ Skipped **{file.name}** — embedding API failed.").send()
            skipped += 1
            continue

        # ── Score ─────────────────────────────────────────────────────────────
        tfidf_score     = compute_tfidf_score(jd_text, resume_text)
        embedding_score = compute_embedding_score(jd_embedding, resume_embedding)
        hybrid_score    = compute_hybrid_score(tfidf_score, embedding_score)
        matched         = is_match(hybrid_score)
        label           = fit_label(hybrid_score)

        logger.info(
            f"  → {metadata['name']} ({metadata['email']}) | "
            f"tfidf={tfidf_score:.4f} emb={embedding_score:.4f} "
            f"hybrid={hybrid_score:.4f} fit={label}"
        )

        # ── Store to ChromaDB: ONE resume = ONE chunk ──────────────────────────
        # Metadata makes each chunk self-contained for recruiter queries.
        # Email is the unique person identifier; filename scopes to the upload.
        doc_id = add_resume(
            text            = resume_text,
            embedding       = resume_embedding,
            name            = metadata["name"],
            email           = metadata["email"],
            filename        = file.name,
            tfidf_score     = tfidf_score,
            embedding_score = embedding_score,
            hybrid_score    = hybrid_score,
            matches_jd      = matched,
            session_id      = session_id,
        )

        resumes.append({
            "filename":        file.name,
            "metadata":        metadata,
            "tfidf_score":     tfidf_score,
            "embedding_score": embedding_score,
            "hybrid_score":    hybrid_score,
            "matches_jd":      matched,
            "doc_id":          doc_id,
        })

        await cl.Message(
            content=(
                f"📄 **{file.name}**\n"
                f"> 👤 {metadata['name']}  ·  📧 {metadata['email']}\n"
                f"> TF-IDF: `{tfidf_score:.4f}` · Embedding: `{embedding_score:.4f}` "
                f"· Hybrid: `{hybrid_score:.4f}`  {_fit_emoji(label)} **{label}**\n"
                f"> 💾 Stored in ChromaDB — ID: `{doc_id}`"
            )
        ).send()

    cl.user_session.set("resumes", resumes)
    if skipped:
        await cl.Message(content=f"⚠️ {skipped} file(s) were skipped.").send()

    await step_show_results()


async def step_show_results():
    """Step 3 — Ranked results table + DB stats."""
    resumes = cl.user_session.get("resumes") or []

    if not resumes:
        await cl.Message(content="⚠️ No resumes to rank yet.").send()
        return

    sorted_resumes = sorted(resumes, key=lambda x: x["hybrid_score"], reverse=True)
    table          = _build_results_table(sorted_resumes)
    matched        = sum(1 for r in sorted_resumes if r["matches_jd"])
    unmatched      = len(sorted_resumes) - matched
    stats          = get_collection_stats()

    logger.info(
        f"Results shown — session resumes: {len(sorted_resumes)} | "
        f"total in DB: {stats['total_resumes']}"
    )

    await cl.Message(
        content=(
            "### 🏆 Step 3 of 3 — Ranked Results\n\n"
            f"**Scoring:** TF-IDF `{TFIDF_WEIGHT*100:.0f}%` + "
            f"Embedding `{EMBEDDING_WEIGHT*100:.0f}%`  ·  "
            f"**Threshold:** `{SIMILARITY_THRESHOLD}`\n\n"
            f"{table}\n\n"
            f"**This session:** 🟢/🟡 `{matched}` shortlisted  ·  🔴 `{unmatched}` below threshold\n"
            f"**ChromaDB total:** `{stats['total_resumes']}` resume(s) stored across all sessions\n\n"
            "_TF-IDF = keyword overlap · Embedding = semantic similarity · Hybrid = weighted ATS score_"
        )
    ).send()

    await cl.Message(
        content=(
            "**What next?**\n"
            "- **`more resumes`** — upload more resumes against the same JD\n"
            "- **`show results`** — re-display this ranking\n"
            "- **`db stats`** — check vector database stats\n"
            "- **`restart`** — start over with a new Job Description\n\n"
            "💡 Switch to **🔍 Recruiter Search** to query all stored resumes by skill or experience."
        )
    ).send()


# ════════════════════════════════════════════════════════════════════════════════
# PROFILE 2 — RECRUITER SEARCH
# ════════════════════════════════════════════════════════════════════════════════

async def handle_recruiter_query(query: str):
    """Embed the recruiter's free-text query, search ChromaDB, format and return results."""
    logger.info(f"Recruiter query: '{query}'")

    stats = get_collection_stats()
    if stats["total_resumes"] == 0:
        await cl.Message(
            content=(
                "⚠️ The resume database is empty.\n\n"
                "Switch to **📋 Resume Matcher** profile, upload a JD and some resumes. "
                "They will be automatically stored here."
            )
        ).send()
        return

    n_results    = cl.user_session.get("n_results") or 5
    only_matched = cl.user_session.get("only_matched") or False
    filter_note  = " _(filtered: JD matches only)_" if only_matched else ""

    await cl.Message(
        content=(
            f"🔍 Searching **{stats['total_resumes']}** resume(s) for: *\"{query}\"*{filter_note}..."
        )
    ).send()

    query_embedding = get_embedding(query)
    if not query_embedding:
        logger.error("Recruiter query: embedding API failed")
        await cl.Message(content="❌ Embedding API failed. Check your API key/endpoint.").send()
        return

    candidates = query_resumes(
        query_embedding = query_embedding,
        n_results       = n_results,
        only_matched    = only_matched,
    )

    if not candidates:
        await cl.Message(
            content=(
                f"No results found for **\"{query}\"**.\n\n"
                "Try broader search terms, or remove the `only shortlisted` filter."
            )
        ).send()
        return

    table = _build_search_table(candidates)
    top   = candidates[0]
    top_label = fit_label(top["hybrid_score"])
    date  = top["uploaded_at"][:10] if top.get("uploaded_at") else "N/A"

    await cl.Message(
        content=(
            f"### 🎯 Results for: *\"{query}\"*\n\n"
            f"{table}\n\n"
            f"---\n"
            f"**🥇 Top Match**\n"
            f"> 👤 **{top['name']}**  ·  📧 `{top['email']}`\n"
            f"> Query match: `{top['search_similarity']:.4f}` · "
            f"JD score: `{top['hybrid_score']:.4f}` {_fit_emoji(top_label)}\n"
            f"> Uploaded: {date}\n\n"
            "_Query Match = similarity to your search · JD Hybrid Score = fit against the original JD_"
        )
    ).send()

    logger.info(
        f"Query '{query}' → {len(candidates)} result(s) | "
        f"top: {top['name']} ({top['email']}) sim={top['search_similarity']:.4f}"
    )


# ════════════════════════════════════════════════════════════════════════════════
# CHAINLIT ENTRY POINTS
# ════════════════════════════════════════════════════════════════════════════════

@cl.on_chat_start
async def start():
    profile = cl.user_session.get("chat_profile")
    logger.info(f"Chat started — profile='{profile}'")

    # ── Resume Matcher ─────────────────────────────────────────────────────────
    if profile == "📋 Resume Matcher":
        cl.user_session.set("resumes",      [])
        cl.user_session.set("jd",           None)
        cl.user_session.set("jd_embedding", None)
        cl.user_session.set("session_id",   None)

        stats = get_collection_stats()
        await cl.Message(
            content=(
                "# 🤖 ATS Resume Matcher\n"
                "Hybrid scoring: **TF-IDF** (keyword overlap) + **Embeddings** (semantic meaning).\n"
                "Each resume is stored as **one chunk** in ChromaDB — queryable from the Recruiter Search profile.\n\n"
                f"💾 Vector DB currently holds **{stats['total_resumes']}** resume(s).\n\n"
                "Let's get started! 👇"
            )
        ).send()
        await step_upload_jd()

    # ── Recruiter Search ───────────────────────────────────────────────────────
    elif profile == "🔍 Recruiter Search":
        cl.user_session.set("n_results",    5)
        cl.user_session.set("only_matched", False)

        stats = get_collection_stats()

        if stats["total_resumes"] == 0:
            await cl.Message(
                content=(
                    "# 🔍 Recruiter Search\n\n"
                    "⚠️ The resume database is currently **empty**.\n\n"
                    "Switch to **📋 Resume Matcher**, upload a JD and some resumes first. "
                    "They'll be stored here automatically."
                )
            ).send()
        else:
            await cl.Message(
                content=(
                    "# 🔍 Recruiter Search\n"
                    f"Searching across **{stats['total_resumes']}** stored resume(s).\n\n"
                    "Describe what you're looking for in plain English:\n"
                    "> *\"Find me a LangChain developer\"*\n"
                    "> *\"Who has React and Node.js experience?\"*\n"
                    "> *\"Show candidates with ML and Python skills\"*\n\n"
                    "**Available settings:**\n"
                    "- `set results 10` — how many candidates to return (default: 5, max: 20)\n"
                    "- `only shortlisted` — filter to candidates that passed the JD match threshold\n"
                    "- `show all` — remove that filter\n"
                    "- `db stats` — check the database\n"
                )
            ).send()


@cl.on_message
async def on_message(message: cl.Message):
    profile = cl.user_session.get("chat_profile")
    text    = message.content.strip()
    lower   = text.lower()

    # ── Resume Matcher commands ────────────────────────────────────────────────
    if profile == "📋 Resume Matcher":

        if any(k in lower for k in ["more resumes", "upload more", "add resumes"]):
            if not cl.user_session.get("jd"):
                await cl.Message(content="⚠️ No JD loaded. Say **restart** to begin again.").send()
            else:
                await step_upload_resumes()

        elif any(k in lower for k in ["restart", "reset", "new jd", "start over"]):
            cl.user_session.set("resumes", [])
            cl.user_session.set("jd",      None)
            cl.user_session.set("jd_embedding", None)
            await cl.Message(content="🔄 Session cleared — starting fresh...").send()
            await step_upload_jd()

        elif any(k in lower for k in ["result", "rank", "show", "table"]):
            await step_show_results()

        elif "db stats" in lower or "database" in lower:
            stats = get_collection_stats()
            await cl.Message(
                content=(
                    f"💾 **ChromaDB Stats**\n"
                    f"> Collection: `{stats['collection']}`\n"
                    f"> Total resumes: `{stats['total_resumes']}`\n"
                    f"> Path: `{stats['path']}`"
                )
            ).send()

        else:
            await cl.Message(
                content=(
                    "I didn't catch that. Try:\n"
                    "- **`more resumes`** — upload more\n"
                    "- **`show results`** — re-display rankings\n"
                    "- **`db stats`** — check ChromaDB\n"
                    "- **`restart`** — new JD"
                )
            ).send()

    # ── Recruiter Search commands ──────────────────────────────────────────────
    elif profile == "🔍 Recruiter Search":

        if lower.startswith("set results"):
            try:
                n = int(lower.split()[-1])
                n = max(1, min(n, 20))
                cl.user_session.set("n_results", n)
                await cl.Message(content=f"✅ Returning up to **{n}** results per query.").send()
            except ValueError:
                await cl.Message(content="Usage: `set results 10`").send()

        elif any(k in lower for k in ["only shortlisted", "only matched", "matched only"]):
            cl.user_session.set("only_matched", True)
            await cl.Message(
                content="✅ Filter active — showing only candidates that matched the JD threshold."
            ).send()

        elif any(k in lower for k in ["show all", "remove filter", "all candidates"]):
            cl.user_session.set("only_matched", False)
            await cl.Message(content="✅ Filter removed — searching all stored resumes.").send()

        elif "db stats" in lower:
            stats = get_collection_stats()
            await cl.Message(
                content=(
                    f"💾 **ChromaDB Stats**\n"
                    f"> Collection: `{stats['collection']}`\n"
                    f"> Total resumes: `{stats['total_resumes']}`\n"
                    f"> Path: `{stats['path']}`"
                )
            ).send()

        else:
            # Every other message is treated as a natural language search query
            await handle_recruiter_query(text)


if __name__ == "__main__":
    cl.run()
