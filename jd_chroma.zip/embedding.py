"""
embedding.py — Embedding API client.
Reads configuration from environment variables.
"""

import os
import logging
import requests
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

API_KEY         = os.getenv("API_KEY")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL")
EMBEDDING_URL   = os.getenv("EMBEDDING_URL", "https://api.openai.com/v1/embeddings")


def get_embedding(text: str) -> list | None:
    """
    Call the configured embedding API and return the embedding vector.
    Returns None on any failure so callers can decide how to handle it.
    """
    if not API_KEY:
        logger.error("API_KEY is not set in environment")
        return None
    if not EMBEDDING_MODEL:
        logger.error("EMBEDDING_MODEL is not set in environment")
        return None

    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {"input": text, "model": EMBEDDING_MODEL}

    try:
        response = requests.post(EMBEDDING_URL, headers=headers, json=payload, timeout=30)
        response.raise_for_status()
        embedding = response.json()["data"][0]["embedding"]
        logger.debug(f"Embedding generated — dim={len(embedding)}")
        return embedding
    except requests.HTTPError as e:
        logger.error(f"Embedding API HTTP error {e.response.status_code}: {e.response.text}")
        return None
    except Exception as err:
        logger.error(f"Embedding API error: {err}")
        return None
