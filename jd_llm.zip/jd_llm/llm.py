"""
llm.py — LLM client for the two justified use cases:

  1. extract_metadata_llm()   → structured candidate info from raw resume text
  2. summarise_search_llm()   → recruiter-friendly narrative from search results

Uses your company endpoint:
  OPENAI_COMPACT_URL  — base API URL
  COMPLETION_MODEL    — model name
  API_KEY             — same key already in .env
"""

import os
import json
import logging
import requests
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

API_KEY      = os.getenv("API_KEY")
MODEL        = os.getenv("COMPLETION_MODEL")
BASE_URL     = os.getenv("OPENAI_COMPACT_URL", "").rstrip("/")
ENDPOINT     = f"{BASE_URL}/chat/completions"

# Truncate resume text sent to LLM — first 3000 chars is plenty for metadata
_METADATA_TEXT_LIMIT  = 3000
# Truncate resume snippet sent per candidate in search summary
_SEARCH_SNIPPET_LIMIT = 400


def _call_llm(messages: list, temperature: float = 0.0, max_tokens: int = 512) -> str | None:
    """
    Core HTTP call to the completion endpoint.
    Returns the assistant message text, or None on failure.
    temperature=0 for deterministic structured outputs.
    """
    if not API_KEY or not MODEL or not BASE_URL:
        logger.error("LLM not configured — check API_KEY, COMPLETION_MODEL, OPENAI_COMPACT_URL in .env")
        return None

    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type":  "application/json",
    }
    payload = {
        "model":       MODEL,
        "messages":    messages,
        "temperature": temperature,
        "max_tokens":  max_tokens,
    }

    try:
        resp = requests.post(ENDPOINT, headers=headers, json=payload, timeout=30)
        resp.raise_for_status()
        content = resp.json()["choices"][0]["message"]["content"].strip()
        logger.debug(f"LLM response ({len(content)} chars)")
        return content
    except requests.HTTPError as e:
        logger.error(f"LLM HTTP {e.response.status_code}: {e.response.text[:300]}")
        return None
    except Exception as e:
        logger.error(f"LLM call failed: {e}")
        return None


# ── Use Case 1: Metadata Extraction ──────────────────────────────────────────

def extract_metadata_llm(resume_text: str) -> dict | None:
    """
    Extract structured candidate metadata from raw resume text using the LLM.

    Returns a dict with keys: name, email, phone, years_of_experience, current_role
    Returns None if the LLM call fails (caller should fall back to regex).
    """
    snippet = resume_text[:_METADATA_TEXT_LIMIT]

    messages = [
        {
            "role": "system",
            "content": (
                "You are a resume parser. Extract structured information from the resume text provided. "
                "Respond ONLY with a valid JSON object — no explanation, no markdown, no extra text. "
                "Use exactly these keys:\n"
                "  name               — candidate's full name (string, or 'Unknown' if not found)\n"
                "  email              — email address (string, or 'N/A' if not found)\n"
                "  phone              — phone number (string, or 'N/A' if not found)\n"
                "  years_of_experience — total years of work experience as an integer (0 if unclear)\n"
                "  current_role       — most recent job title (string, or 'N/A' if not found)"
            ),
        },
        {
            "role": "user",
            "content": f"Resume text:\n\n{snippet}",
        },
    ]

    raw = _call_llm(messages, temperature=0.0, max_tokens=256)
    if not raw:
        return None

    # Strip markdown code fences if the model wraps it anyway
    clean = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()

    try:
        data = json.loads(clean)
        # Normalise to expected shape with safe fallbacks
        return {
            "name":                str(data.get("name", "Unknown")).strip() or "Unknown",
            "email":               str(data.get("email", "N/A")).strip() or "N/A",
            "phone":               str(data.get("phone", "N/A")).strip() or "N/A",
            "years_of_experience": int(data.get("years_of_experience", 0)),
            "current_role":        str(data.get("current_role", "N/A")).strip() or "N/A",
        }
    except (json.JSONDecodeError, ValueError) as e:
        logger.error(f"Failed to parse LLM metadata JSON: {e} | raw='{raw[:200]}'")
        return None


# ── Use Case 2: Recruiter Search Summarisation ────────────────────────────────

def summarise_search_llm(query: str, candidates: list) -> str | None:
    """
    Given a recruiter's natural-language query and the top ChromaDB results,
    ask the LLM to write a concise, useful recruiter summary.

    candidates: list of dicts from query_resumes() — each has name, email,
                hybrid_score, search_similarity, uploaded_at, and optionally
                current_role / years_of_experience if stored in metadata.

    Returns a markdown string, or None if the LLM call fails.
    """
    if not candidates:
        return None

    # Build a compact candidate list for the prompt — avoid sending full resume text
    candidate_lines = []
    for i, c in enumerate(candidates, 1):
        line = (
            f"{i}. {c['name']} ({c['email']})"
            f" | Query match: {c['search_similarity']:.2f}"
            f" | JD hybrid score: {c['hybrid_score']:.2f}"
            f" | JD matched: {'Yes' if c['matches_jd'] else 'No'}"
        )
        # Include extra metadata fields if available (added by LLM extractor)
        if c.get("current_role") and c["current_role"] != "N/A":
            line += f" | Role: {c['current_role']}"
        if c.get("years_of_experience"):
            line += f" | Exp: {c['years_of_experience']} yrs"
        candidate_lines.append(line)

    candidates_block = "\n".join(candidate_lines)

    messages = [
        {
            "role": "system",
            "content": (
                "You are an expert technical recruiter assistant. "
                "A recruiter has searched a resume database and you have the top results. "
                "Write a concise, natural summary (3–6 sentences) that:\n"
                "  - Directly answers the recruiter's query\n"
                "  - Highlights the strongest candidate and why they stand out\n"
                "  - Notes any important differences between candidates\n"
                "  - Flags if no strong match was found\n"
                "Be specific, use names, and write in plain English. No bullet points."
            ),
        },
        {
            "role": "user",
            "content": (
                f"Recruiter query: \"{query}\"\n\n"
                f"Top candidates from the database:\n{candidates_block}"
            ),
        },
    ]

    return _call_llm(messages, temperature=0.3, max_tokens=300)
