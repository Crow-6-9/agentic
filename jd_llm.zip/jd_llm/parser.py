import re
import logging
from docx import Document

logger = logging.getLogger(__name__)


def extract_text_from_docx(file_path: str) -> str:
    """Extract clean text from a .docx file."""
    doc = Document(file_path)
    return "\n".join([p.text for p in doc.paragraphs if p.text.strip()])


def _regex_fallback(text: str) -> dict:
    """
    Regex-based metadata extraction.
    Used as fallback when the LLM call fails or is unavailable.
    """
    email_match = re.search(
        r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}",
        text,
    )
    email = email_match.group(0) if email_match else "N/A"

    lines = [l.strip() for l in text.splitlines() if l.strip()]
    raw   = lines[0] if lines else "Unknown"
    name  = raw if re.match(r"^[A-Za-z .'\-]{2,50}$", raw) else "Unknown"

    return {
        "name":                name,
        "email":               email,
        "phone":               "N/A",
        "years_of_experience": 0,
        "current_role":        "N/A",
    }


def extract_metadata(text: str) -> dict:
    """
    Extract candidate metadata from resume text.

    Primary  → LLM (structured JSON: name, email, phone, years_of_experience, current_role)
    Fallback → regex heuristic (name + email only) if LLM fails or is not configured
    """
    # Import here to avoid circular imports and to keep LLM optional
    try:
        from services.llm import extract_metadata_llm
        result = extract_metadata_llm(text)
        if result:
            logger.info(
                f"LLM metadata — name='{result['name']}' email='{result['email']}' "
                f"role='{result['current_role']}' exp={result['years_of_experience']}yrs"
            )
            return result
        else:
            logger.warning("LLM metadata extraction returned None — falling back to regex")
    except Exception as e:
        logger.warning(f"LLM metadata extraction failed ({e}) — falling back to regex")

    result = _regex_fallback(text)
    logger.info(f"Regex metadata — name='{result['name']}' email='{result['email']}'")
    return result
