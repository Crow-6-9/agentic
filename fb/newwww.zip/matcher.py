import logging
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

logger = logging.getLogger(__name__)

TFIDF_WEIGHT         = 0.4
EMBEDDING_WEIGHT     = 0.6
SIMILARITY_THRESHOLD = 0.7


def compute_tfidf_score(jd_text: str, resume_text: str) -> float:
    try:
        vec    = TfidfVectorizer(stop_words="english")
        matrix = vec.fit_transform([jd_text, resume_text])
        return float(cosine_similarity(matrix[0:1], matrix[1:2])[0][0])
    except Exception as e:
        logger.error(f"TF-IDF error: {e}")
        return 0.0


def compute_embedding_score(jd_embedding: list, resume_embedding: list) -> float:
    return float(cosine_similarity([jd_embedding], [resume_embedding])[0][0])


def compute_hybrid_score(tfidf: float, embedding: float) -> float:
    return round(TFIDF_WEIGHT * tfidf + EMBEDDING_WEIGHT * embedding, 4)


def fit_label(score: float) -> str:
    """Fit label based on embedding score (primary signal)."""
    if score >= 0.85:
        return "Strong"
    elif score >= SIMILARITY_THRESHOLD:
        return "Good"
    return "Weak"


def is_match(embedding_score: float) -> bool:
    """Match decision driven by embedding score — not hybrid."""
    return embedding_score >= SIMILARITY_THRESHOLD
