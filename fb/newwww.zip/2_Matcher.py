"""
Page 2 — Resume Matcher
Step 1: Upload JD → Step 2: Upload Resumes → Step 3: Ranked Results
"""

import os
import uuid
import shutil
import tempfile
import logging

import streamlit as st
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

from services.parser      import extract_text_from_docx, extract_metadata, extract_primary_skills
from services.embedding   import get_embedding
from services.matcher     import (
    compute_tfidf_score,
    compute_embedding_score,
    compute_hybrid_score,
    fit_label,
    is_match,
    TFIDF_WEIGHT,
    EMBEDDING_WEIGHT,
    SIMILARITY_THRESHOLD,
)
from services.vectorstore import add_resume, get_stats

st.set_page_config(page_title="Matcher", page_icon="📋", layout="wide")
st.title("📋 Resume Matcher")
st.caption(
    f"TF-IDF `{int(TFIDF_WEIGHT*100)}%` + Embedding `{int(EMBEDDING_WEIGHT*100)}%`  ·  "
    f"Match decision: Embedding score ≥ `{SIMILARITY_THRESHOLD}`"
)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _fit_badge(label: str) -> str:
    return {"Strong": "🟢 Strong", "Good": "🟡 Good", "Weak": "🔴 Weak"}.get(label, label)


def _write_tmp(f) -> str:
    suffix = os.path.splitext(f.name)[-1]
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(f.read())
        return tmp.name


def _save_locally(tmp_path: str, filename: str) -> None:
    folder = os.path.join(os.path.dirname(__file__), "..", "resumes")
    os.makedirs(folder, exist_ok=True)
    shutil.copy2(tmp_path, os.path.join(folder, filename))


# ── Session state ─────────────────────────────────────────────────────────────

for k, v in {
    "jd_text": None, "jd_embedding": None,
    "session_id": str(uuid.uuid4()), "results": []
}.items():
    if k not in st.session_state:
        st.session_state[k] = v


# ════════════════════════════════════════════════════════════════════════════════
# STEP 1 — JOB DESCRIPTION
# ════════════════════════════════════════════════════════════════════════════════

st.subheader("Step 1 — Upload Job Description")

jd_file = st.file_uploader(
    "Upload the JD as a .docx file",
    type = ["docx"],
    key  = "jd_uploader",
)

if jd_file and not st.session_state.jd_text:
    with st.spinner(f"Reading and embedding **{jd_file.name}**..."):
        tmp = _write_tmp(jd_file)
        try:
            jd_text = extract_text_from_docx(tmp)
        finally:
            os.unlink(tmp)
        jd_embedding = get_embedding(jd_text)

    if not jd_embedding:
        st.error("❌ Embedding failed. Check `API_KEY`, `EMBEDDING_MODEL`, `EMBEDDING_URL` in `.env`.")
    else:
        st.session_state.jd_text      = jd_text
        st.session_state.jd_embedding = jd_embedding
        st.session_state.results      = []
        logger.info(f"JD loaded — session={st.session_state.session_id}  file={jd_file.name}")

if st.session_state.jd_text:
    st.success("✅ Job Description ready")
    with st.expander("Preview JD text"):
        st.text(
            st.session_state.jd_text[:1500]
            + ("..." if len(st.session_state.jd_text) > 1500 else "")
        )


# ════════════════════════════════════════════════════════════════════════════════
# STEP 2 — UPLOAD RESUMES
# ════════════════════════════════════════════════════════════════════════════════

st.divider()
st.subheader("Step 2 — Upload Resumes")

if not st.session_state.jd_text:
    st.info("⬆️ Upload a Job Description above first.")
else:
    resume_files = st.file_uploader(
        "Upload resumes (.docx) — up to 10 at once",
        type                  = ["docx"],
        accept_multiple_files = True,
        key                   = "resume_uploader",
    )

    if resume_files:
        already   = {r["File"] for r in st.session_state.results}
        new_files = [f for f in resume_files if f.name not in already]

        if new_files:
            jd_text      = st.session_state.jd_text
            jd_embedding = st.session_state.jd_embedding
            session_id   = st.session_state.session_id
            new_results  = []
            skipped      = 0

            progress = st.progress(0, text="Processing resumes...")

            for i, file in enumerate(new_files[:10]):
                progress.progress(i / len(new_files), text=f"Processing {file.name}...")
                tmp_path = _write_tmp(file)

                try:
                    full_text = extract_text_from_docx(tmp_path)
                    _save_locally(tmp_path, file.name)
                except Exception as e:
                    st.warning(f"⚠️ Skipped **{file.name}** — could not read: {e}")
                    skipped += 1
                    continue
                finally:
                    if os.path.exists(tmp_path):
                        os.unlink(tmp_path)

                meta           = extract_metadata(full_text)
                primary_skills = extract_primary_skills(full_text)
                emb_vec        = get_embedding(full_text)

                if not emb_vec:
                    st.warning(f"⚠️ Skipped **{file.name}** — embedding API failed.")
                    skipped += 1
                    continue

                tfidf   = compute_tfidf_score(jd_text, full_text)
                emb     = compute_embedding_score(jd_embedding, emb_vec)
                hybrid  = compute_hybrid_score(tfidf, emb)
                matched = is_match(emb)      # embedding score drives match decision
                label   = fit_label(emb)       # embedding score drives fit label

                doc_id = add_resume(
                    text            = full_text,
                    embedding       = emb_vec,
                    name            = meta["name"],
                    email           = meta["email"],
                    filename        = file.name,
                    primary_skills  = primary_skills,
                    tfidf_score     = tfidf,
                    embedding_score = emb,
                    hybrid_score    = hybrid,
                    matches_jd      = matched,
                    session_id      = session_id,
                )

                new_results.append({
                    "Name":           meta["name"],
                    "Email":          meta["email"],
                    "Primary Skills": primary_skills,
                    "File":           file.name,
                    "TF-IDF":         round(tfidf, 4),
                    "Embedding":      round(emb, 4),
                    "Hybrid":         round(hybrid, 4),
                    "Fit":            _fit_badge(label),
                    "Matches JD":     "✅" if matched else "❌",
                    "_emb":           emb,
                    "_hybrid":        hybrid,
                })

                logger.info(
                    f"{meta['name']} ({meta['email']}) | "
                    f"tfidf={tfidf:.4f} emb={emb:.4f} hybrid={hybrid:.4f} → {label}"
                )

            progress.progress(1.0, text="Done!")
            st.session_state.results += new_results

            if skipped:
                st.warning(f"⚠️ {skipped} file(s) skipped.")

            stats = get_stats()
            st.success(
                f"✅ {len(new_results)} resume(s) processed and stored.  "
                f"ChromaDB total: **{stats['total']}**"
            )


# ════════════════════════════════════════════════════════════════════════════════
# STEP 3 — RANKED RESULTS
# ════════════════════════════════════════════════════════════════════════════════

if st.session_state.results:
    st.divider()
    st.subheader("Step 3 — Ranked Results")

    sorted_r  = sorted(st.session_state.results, key=lambda x: x["_emb"], reverse=True)
    display   = [{k: v for k, v in r.items() if not k.startswith("_")} for r in sorted_r]
    matched   = sum(1 for r in sorted_r if r["Matches JD"] == "✅")
    unmatched = len(sorted_r) - matched

    c1, c2, c3 = st.columns(3)
    c1.metric("Total this session",  len(sorted_r))
    c2.metric("🟢/🟡 Shortlisted",  matched)
    c3.metric("🔴 Below threshold",  unmatched)

    st.dataframe(
        display,
        use_container_width = True,
        hide_index          = True,
        column_config       = {
            "TF-IDF":    st.column_config.NumberColumn(format="%.4f"),
            "Embedding": st.column_config.NumberColumn(format="%.4f"),
            "Hybrid":    st.column_config.NumberColumn(format="%.4f"),
        },
    )

    if st.button("🔄 Start over with a new JD"):
        st.session_state.update({
            "jd_text":      None,
            "jd_embedding": None,
            "results":      [],
            "session_id":   str(uuid.uuid4()),
        })
        st.rerun()
