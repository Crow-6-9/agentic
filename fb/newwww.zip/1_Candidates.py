"""
Page 1 — Candidates
- Shows all uploaded resumes: ID, Name, Email, Primary Skills, File
- Upload resume directly here (no JD needed) → appears in list immediately
- List auto-refreshes after every upload
"""

import os
import uuid
import shutil
import tempfile
import logging

import streamlit as st
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

from services.parser      import extract_text_from_docx, extract_metadata, extract_primary_skills
from services.embedding   import get_embedding
from services.vectorstore import add_resume, get_all_resumes, get_stats

st.set_page_config(page_title="Candidates", page_icon="👥", layout="wide")
st.title("👥 Candidates")
st.caption("All uploaded resumes · Upload new resumes here · List updates instantly")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _write_tmp(uploaded_file) -> str:
    suffix = os.path.splitext(uploaded_file.name)[-1]
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(uploaded_file.read())
        return tmp.name


def _save_locally(tmp_path: str, filename: str) -> None:
    folder = os.path.join(os.path.dirname(__file__), "..", "resumes")
    os.makedirs(folder, exist_ok=True)
    shutil.copy2(tmp_path, os.path.join(folder, filename))


# ════════════════════════════════════════════════════════════════════════════════
# UPLOAD SECTION
# ════════════════════════════════════════════════════════════════════════════════

st.subheader("Upload Resumes")
st.caption("Upload without a JD — resumes are stored and searchable immediately.")

uploaded = st.file_uploader(
    "Choose .docx resume files",
    type                  = ["docx"],
    accept_multiple_files = True,
    key                   = "candidate_uploader",
)

if uploaded:
    existing_files = {r["filename"] for r in get_all_resumes()}
    new_files      = [f for f in uploaded if f.name not in existing_files]

    if not new_files:
        st.info("All uploaded files are already in the database.")
    else:
        progress  = st.progress(0, text="Uploading...")
        added     = []
        skipped   = 0

        for i, file in enumerate(new_files):
            progress.progress(i / len(new_files), text=f"Processing {file.name}...")
            tmp_path = _write_tmp(file)

            try:
                text = extract_text_from_docx(tmp_path)
                _save_locally(tmp_path, file.name)
            except Exception as e:
                st.warning(f"⚠️ Skipped **{file.name}** — {e}")
                skipped += 1
                continue
            finally:
                if os.path.exists(tmp_path):
                    os.unlink(tmp_path)

            meta           = extract_metadata(text)
            primary_skills = extract_primary_skills(text)
            embedding      = get_embedding(text)

            if not embedding:
                st.warning(f"⚠️ Skipped **{file.name}** — embedding API failed.")
                skipped += 1
                continue

            add_resume(
                text            = text,
                embedding       = embedding,
                name            = meta["name"],
                email           = meta["email"],
                filename        = file.name,
                primary_skills  = primary_skills,
                tfidf_score     = 0.0,
                embedding_score = 0.0,
                hybrid_score    = 0.0,
                matches_jd      = False,
                session_id      = "direct_upload",
            )
            added.append(meta["name"])
            logger.info(f"Direct upload: {meta['name']} ({meta['email']}) — {file.name}")

        progress.progress(1.0, text="Done!")

        if added:
            st.success(f"✅ Added **{len(added)}** candidate(s): {', '.join(added)}")
        if skipped:
            st.warning(f"⚠️ {skipped} file(s) skipped.")

        st.rerun()   # refresh the list below immediately


# ════════════════════════════════════════════════════════════════════════════════
# CANDIDATES LIST
# ════════════════════════════════════════════════════════════════════════════════

st.divider()

stats    = get_stats()
all_recs = get_all_resumes()

st.subheader(f"All Candidates  —  {stats['total']} total")

if not all_recs:
    st.info("No candidates yet. Upload resumes above.")
else:
    # Search / filter within the list
    search_name = st.text_input(
        "🔎 Filter by name or skill",
        placeholder = "e.g. 'John' or 'hadoop'",
        label_visibility = "collapsed",
    )

    rows = []
    for i, r in enumerate(all_recs, 1):
        if search_name:
            haystack = f"{r['name']} {r['primary_skills']} {r['email']}".lower()
            if search_name.lower() not in haystack:
                continue
        rows.append({
            "ID":             i,
            "Name":           r["name"],
            "Email":          r["email"],
            "Primary Skills": r["primary_skills"],
            "Resume File":    r["filename"],
            "Uploaded":       r["uploaded_at"][:10] if r.get("uploaded_at") else "N/A",
        })

    if not rows:
        st.warning(f"No candidates match **'{search_name}'**.")
    else:
        # Header row
        h1, h2, h3, h4, h5, h6 = st.columns([1, 2, 3, 4, 3, 1])
        h1.markdown("**#**")
        h2.markdown("**Name**")
        h3.markdown("**Email**")
        h4.markdown("**Primary Skills**")
        h5.markdown("**Resume File**")
        h6.markdown("**Download**")
        st.divider()

        resumes_dir = os.path.join(os.path.dirname(__file__), "..", "resumes")
        for row in rows:
            c1, c2, c3, c4, c5, c6 = st.columns([1, 2, 3, 4, 3, 1])
            c1.write(row["ID"])
            c2.write(row["Name"])
            c3.write(row["Email"])
            c4.write(row["Primary Skills"])
            c5.write(row["Resume File"])
            # Download button — only if file exists locally
            resume_path = os.path.join(resumes_dir, row["Resume File"])
            if os.path.exists(resume_path):
                with open(resume_path, "rb") as fh:
                    c6.download_button(
                        label    = "⬇️",
                        data     = fh.read(),
                        file_name = row["Resume File"],
                        mime     = "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        key      = f"dl_cand_{row['ID']}",
                    )
            else:
                c6.write("—")

        st.caption(f"Showing {len(rows)} of {stats['total']} candidate(s)")
