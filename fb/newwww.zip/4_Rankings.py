"""
Page 4 — Rankings
Two views:
  Simple  — Name, Email, Primary Skills, File (clean, non-technical)
  Detailed — Full scores + filters + charts (for analysis)
"""

import os
import logging

import pandas as pd
import streamlit as st
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

from services.matcher     import fit_label, SIMILARITY_THRESHOLD
from services.vectorstore import get_all_resumes, get_stats

st.set_page_config(page_title="Rankings", page_icon="📊", layout="wide")
st.title("📊 Rankings")

stats = get_stats()
if stats["total"] == 0:
    st.warning("⚠️ No resumes stored yet. Upload resumes via **👥 Candidates** or **📋 Matcher**.")
    st.stop()


# ── View toggle ───────────────────────────────────────────────────────────────

view = st.radio(
    "View",
    options    = ["🗂 Simple View", "📈 Detailed View"],
    horizontal = True,
)

st.divider()

with st.spinner("Loading from ChromaDB..."):
    resumes = get_all_resumes()

if not resumes:
    st.info("No resumes found.")
    st.stop()


# ════════════════════════════════════════════════════════════════════════════════
# SIMPLE VIEW — clean, non-technical
# ════════════════════════════════════════════════════════════════════════════════

if view == "🗂 Simple View":
    st.subheader(f"All Candidates  —  {len(resumes)} total")

    filter_name = st.text_input(
        "Filter", placeholder="Filter by name, email, or skill...",
        label_visibility="collapsed"
    )

    rows = []
    for i, r in enumerate(resumes, 1):
        if filter_name:
            haystack = f"{r['name']} {r['email']} {r['primary_skills']}".lower()
            if filter_name.lower() not in haystack:
                continue
        rows.append({
            "#":              i,
            "Name":           r["name"],
            "Email":          r["email"],
            "Primary Skills": r["primary_skills"],
            "Resume File":    r["filename"],
            "Uploaded":       r["uploaded_at"][:10] if r.get("uploaded_at") else "N/A",
        })

    if not rows:
        st.warning(f"No candidates match **'{filter_name}'**.")
    else:
        resumes_dir = os.path.join(os.path.dirname(__file__), "..", "resumes")
        h1, h2, h3, h4, h5, h6 = st.columns([1, 2, 3, 4, 3, 1])
        h1.markdown("**#**"); h2.markdown("**Name**"); h3.markdown("**Email**")
        h4.markdown("**Primary Skills**"); h5.markdown("**Resume File**"); h6.markdown("**Download**")
        st.divider()
        for row in rows:
            c1, c2, c3, c4, c5, c6 = st.columns([1, 2, 3, 4, 3, 1])
            c1.write(row["#"]); c2.write(row["Name"]); c3.write(row["Email"])
            c4.write(row["Primary Skills"]); c5.write(row["Resume File"])
            resume_path = os.path.join(resumes_dir, row["Resume File"])
            if os.path.exists(resume_path):
                with open(resume_path, "rb") as fh:
                    c6.download_button(
                        label     = "⬇️",
                        data      = fh.read(),
                        file_name = row["Resume File"],
                        mime      = "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        key       = f"dl_rank_{row['#']}",
                    )
            else:
                c6.write("—")
        st.caption(f"Showing {len(rows)} of {len(resumes)} candidate(s)")


# ════════════════════════════════════════════════════════════════════════════════
# DETAILED VIEW — full scores, filters, charts
# ════════════════════════════════════════════════════════════════════════════════

else:
    # Controls
    col1, col2, col3 = st.columns([2, 2, 1])
    with col1:
        sort_by = st.selectbox(
            "Sort by",
            ["Embedding Score", "Hybrid Score", "TF-IDF Score"],
        )
    with col2:
        filter_fit = st.multiselect(
            "Filter by Fit",
            ["Strong", "Good", "Weak"],
            default=["Strong", "Good", "Weak"],
        )
    with col3:
        st.markdown("<br>", unsafe_allow_html=True)
        if st.button("🔄 Refresh", use_container_width=True):
            st.rerun()

    sort_key = {"Embedding Score": "embedding_score",
                "Hybrid Score":    "hybrid_score",
                "TF-IDF Score":    "tfidf_score"}[sort_by]

    sorted_r = sorted(resumes, key=lambda r: r[sort_key], reverse=True)

    def _badge(score):
        l = fit_label(score)
        return {"Strong":"🟢","Good":"🟡","Weak":"🔴"}.get(l,"⚪") + " " + l

    # Summary metrics
    total   = len(resumes)
    strong  = sum(1 for r in resumes if fit_label(r["hybrid_score"]) == "Strong")
    good    = sum(1 for r in resumes if fit_label(r["hybrid_score"]) == "Good")
    weak    = sum(1 for r in resumes if fit_label(r["hybrid_score"]) == "Weak")
    matched = sum(1 for r in resumes if r["matches_jd"])

    m1, m2, m3, m4, m5 = st.columns(5)
    m1.metric("Total",        total)
    m2.metric("🟢 Strong",    strong)
    m3.metric("🟡 Good",      good)
    m4.metric("🔴 Weak",      weak)
    m5.metric("✅ JD Matched", matched)

    st.divider()

    rows = []
    for i, r in enumerate(sorted_r, 1):
        if fit_label(r["hybrid_score"]) not in filter_fit:
            continue
        rows.append({
            "Rank":           i,
            "Name":           r["name"],
            "Email":          r["email"],
            "Primary Skills": r["primary_skills"],
            "File":           r["filename"],
            "TF-IDF":         round(r["tfidf_score"], 4),
            "Embedding":      round(r["embedding_score"], 4),
            "Hybrid":         round(r["hybrid_score"], 4),
            "JD Match":       "✅" if r["matches_jd"] else "❌",
            "Fit":            _badge(r["hybrid_score"]),
            "Uploaded":       r["uploaded_at"][:10] if r.get("uploaded_at") else "N/A",
        })

    if not rows:
        st.info("No resumes match the selected filters.")
        st.stop()

    st.markdown(f"**{len(rows)}** candidate(s) · sorted by **{sort_by}**")

    st.dataframe(
        rows,
        use_container_width = True,
        hide_index          = True,
        column_config       = {
            "TF-IDF":    st.column_config.NumberColumn(format="%.4f"),
            "Embedding": st.column_config.NumberColumn(
                format="%.4f",
                help="Primary ranking score — semantic similarity"
            ),
            "Hybrid":    st.column_config.NumberColumn(
                format="%.4f",
                help=f"Weighted blend (40% TF-IDF + 60% Embedding) · threshold={SIMILARITY_THRESHOLD}"
            ),
        },
    )

    # Download buttons below the detailed table
    resumes_dir = os.path.join(os.path.dirname(__file__), "..", "resumes")
    st.markdown("**Download resumes:**")
    dl_cols = st.columns(min(len(rows), 5))
    for idx, row in enumerate(rows):
        resume_path = os.path.join(resumes_dir, row["File"])
        col = dl_cols[idx % len(dl_cols)]
        if os.path.exists(resume_path):
            with open(resume_path, "rb") as fh:
                col.download_button(
                    label     = f"⬇️ {row['Name']}",
                    data      = fh.read(),
                    file_name = row["File"],
                    mime      = "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    key       = f"dl_det_{idx}",
                )

    # Charts
    st.divider()
    st.subheader("Score Distribution")
    df = pd.DataFrame(rows)

    tab1, tab2, tab3 = st.tabs(["Embedding", "Hybrid", "TF-IDF"])
    with tab1:
        st.bar_chart(df.set_index("Name")["Embedding"], color="#4f8bf9", use_container_width=True)
    with tab2:
        st.bar_chart(df.set_index("Name")["Hybrid"],    color="#f97b4f", use_container_width=True)
    with tab3:
        st.bar_chart(df.set_index("Name")["TF-IDF"],    color="#4ff9a0", use_container_width=True)
