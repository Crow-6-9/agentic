from configs.parser import TrainingConfig
from core.trainer import BaseTrainer
from models.gpt2 import GPT2Trainer
from models.flant5 import FlanT5Trainer

class TrainerFactory:
    """Factory pattern for trainer selection"""
    
    _trainers = {
        'gpt2': GPT2Trainer,
        'flant5': FlanT5Trainer,
        't5': FlanT5Trainer
    }
    
    @classmethod
    def create(cls, config: TrainingConfig) -> BaseTrainer:
        trainer_cls = cls._trainers.get(config.model.lower())
        if not trainer_cls:
            raise ValueError(f"Unsupported model: {config.model}")
        return trainer_cls(config)
