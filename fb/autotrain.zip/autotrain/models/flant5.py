from typing import List
from transformers import AutoModelForSeq2SeqLM, Seq2SeqTrainingArguments, DataCollatorForSeq2Seq
from datasets import Dataset

from core.trainer import BaseTrainer

class FlanT5Trainer(BaseTrainer):
    """FLAN-T5 specific trainer"""
    
    def _load_model(self):
        return AutoModelForSeq2SeqLM.from_pretrained(
            self.config.model_path, 
            local_files_only=True
        )
    
    def _create_dataset(self, texts: List[str]) -> Dataset:
        # Create input-target pairs
        inputs = [f"Process: {text[:100]}" for text in texts]
        targets = texts
        
        model_inputs = self.tokenizer(
            inputs,
            max_length=self.config.max_length,
            truncation=True,
            padding='max_length'
        )
        
        with self.tokenizer.as_target_tokenizer():
            labels = self.tokenizer(
                targets,
                max_length=self.config.max_length,
                truncation=True,
                padding='max_length'
            )
        
        model_inputs['labels'] = labels['input_ids']
        return Dataset.from_dict(model_inputs)
    
    def _get_training_args(self) -> Seq2SeqTrainingArguments:
        return Seq2SeqTrainingArguments(
            output_dir=self.output_dir,
            num_train_epochs=self.config.epochs,
            per_device_train_batch_size=self.config.batch_size,
            learning_rate=self.config.learning_rate,
            use_cpu=True,
            save_strategy="epoch",
            report_to="none",
            logging_steps=10,
            prediction_loss_only=True
        )
    
    def _get_data_collator(self):
        return DataCollatorForSeq2Seq(
            tokenizer=self.tokenizer, 
            model=self.model
        )
