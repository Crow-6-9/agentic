#!/usr/bin/env python3
import sys
import os

# Add current directory to path so modules can be imported if run directly
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from configs.parser import parse_config_file
from utils.data import DataNormalizer
from models.factory import TrainerFactory

def main():
    print("=" * 50)
    print("🤖 Automated Model Training System")
    print("=" * 50)
    
    # Question 1: Model Choice
    model_choice = ""
    while model_choice not in ['gpt2', 'flant5', 't5']:
        model_choice = input("Which model do you want to train? (gpt2 / flant5): ").strip().lower()
        if model_choice not in ['gpt2', 'flant5', 't5']:
            print("Invalid choice. Please choose 'gpt2' or 'flant5'.")
            
    # Question 2: Config Path
    config_path = ""
    while not os.path.isfile(config_path):
        config_path = input("\nPlease share the path to your config.txt file: ").strip()
        # Remove quotes if user dragged and dropped
        if config_path.startswith('"') and config_path.endswith('"'):
            config_path = config_path[1:-1]
        if not os.path.isfile(config_path):
            print(f"File not found: {config_path}")
            
    try:
        # Load configs
        config = parse_config_file(config_path, model_choice)
        print(f"\n✅ Configurations loaded successfully.")
        print(f"🔧 Training Method: {config.training_method.upper()}")
        if config.is_lora:
            print(f"   LoRA R: {config.lora_r}, Alpha: {config.lora_alpha}, Dropout: {config.lora_dropout}")
        
        # Load dataset
        print(f"\n📂 Loading dataset from {config.data_path}...")
        texts = DataNormalizer.load(config.data_path)
        total_records = len(texts)
        print(f"📊 Found a total of {total_records} records.")
        
        # Question 3: Subset selection
        record_count = -1
        while record_count == -1:
            ans = input(f"\nHow many records do you want to train on? (Enter a number up to {total_records} or 'all'): ").strip().lower()
            if ans == 'all':
                record_count = total_records
            elif ans.isdigit():
                parsed = int(ans)
                if 1 <= parsed <= total_records:
                    record_count = parsed
                else:
                    print(f"Please enter a number between 1 and {total_records}.")
            else:
                print("Invalid input. Enter a number or 'all'.")
        
        # Subset data
        texts_subset = texts[:record_count]
        print(f"✅ Selecting {record_count} records for training.")
        
        # Proceed to train
        print("\n⚙️  Initializing Trainer...")
        trainer = TrainerFactory.create(config)
        trainer.train(texts_subset)
        
    except Exception as e:
        print(f"\n❌ An error occurred: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
