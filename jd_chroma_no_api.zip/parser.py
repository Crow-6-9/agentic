import re
import logging
from docx import Document

logger = logging.getLogger(__name__)


def extract_text_from_docx(file_path: str) -> str:
    """Extract clean text from a .docx file."""
    doc = Document(file_path)
    return "\n".join([p.text for p in doc.paragraphs if p.text.strip()])


def extract_metadata(text: str) -> dict:
    """
    Extract candidate name and email from resume text.

    Email → regex match (reliable)
    Name  → first non-empty line heuristic (most resumes open with candidate's name)
    """
    # Email
    email_match = re.search(
        r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}",
        text,
    )
    email = email_match.group(0) if email_match else "N/A"

    # Name — first non-empty line that looks like a human name
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    raw   = lines[0] if lines else "Unknown"
    name  = raw if re.match(r"^[A-Za-z .'\-]{2,50}$", raw) else "Unknown"

    logger.debug(f"Extracted metadata — name='{name}' email='{email}'")
    return {"name": name, "email": email}
