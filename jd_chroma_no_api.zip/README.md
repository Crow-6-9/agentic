# JD Matcher v2 — Standalone

Hybrid ATS resume scorer with semantic recruiter search. No API server needed — runs as a single Chainlit app.

```
jd_matcher_v2/
├── app.py                  ← Entry point (chainlit run app.py)
├── requirements.txt
├── .env.example            ← Copy to .env and fill in your keys
├── .gitignore
│
├── core/
│   └── logging_config.py  ← Structured logging
│
├── services/
│   ├── parser.py           ← .docx text extraction + name/email extraction
│   ├── embedding.py        ← Embedding API client
│   ├── matcher.py          ← TF-IDF, embedding & hybrid scoring
│   └── vectorstore.py      ← ChromaDB (1 resume = 1 chunk)
│
└── chroma_db/              ← Auto-created on first run (gitignored)
```

## Setup

```bash
cd jd_matcher_v2
cp .env.example .env        # fill in API_KEY, EMBEDDING_MODEL, EMBEDDING_URL
pip install -r requirements.txt
chainlit run app.py
```

Open http://localhost:8000

## Two Profiles

### 📋 Resume Matcher
1. Upload a Job Description (.docx)
2. Upload up to 10 resumes (.docx)
3. See ranked results — TF-IDF, Embedding, and Hybrid scores per candidate
4. Every resume is stored as **one chunk** in ChromaDB with full metadata

### 🔍 Recruiter Search
Type anything in plain English to semantically search all stored resumes:
- *"Find a LangChain developer"*
- *"Who has React and Node.js experience?"*
- *"Candidates with ML and Python skills"*

**Settings:**
| Command | Effect |
|---------|--------|
| `set results 10` | Return up to N results (default 5) |
| `only shortlisted` | Filter to JD-matched candidates |
| `show all` | Remove that filter |
| `db stats` | Show ChromaDB info |

## Scoring

| Method | Measures | Weight |
|--------|----------|--------|
| TF-IDF | Exact keyword overlap | 40% |
| Embedding | Semantic meaning | 60% |
| **Hybrid** | Weighted ATS blend | — |

Fit: `🟢 Strong` ≥ 0.85 · `🟡 Good` ≥ 0.70 · `🔴 Weak` < 0.70

Tune weights in `services/matcher.py`.

## ChromaDB

- Persistent — data survives restarts
- One resume = one document, one embedding, full metadata
- Doc ID: `{email}__{filename}` — email is the unique person key
- Re-uploading the same file safely upserts (overwrites)
