import os
import logging
import requests
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

API_KEY         = os.getenv("API_KEY")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL")
EMBEDDING_URL   = os.getenv("EMBEDDING_URL", "https://api.openai.com/v1/embeddings")


def get_embedding(text: str) -> list | None:
    """
    Call the configured embedding API and return the vector.
    Returns None on any failure.
    """
    if not API_KEY:
        logger.error("API_KEY is not set in .env")
        return None
    if not EMBEDDING_MODEL:
        logger.error("EMBEDDING_MODEL is not set in .env")
        return None

    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type":  "application/json",
    }
    payload = {"input": text, "model": EMBEDDING_MODEL}

    try:
        resp = requests.post(EMBEDDING_URL, headers=headers, json=payload, timeout=30)
        resp.raise_for_status()
        vec = resp.json()["data"][0]["embedding"]
        logger.debug(f"Embedding OK — dim={len(vec)}")
        return vec
    except requests.HTTPError as e:
        logger.error(f"Embedding HTTP {e.response.status_code}: {e.response.text[:200]}")
        return None
    except Exception as e:
        logger.error(f"Embedding error: {e}")
        return None
