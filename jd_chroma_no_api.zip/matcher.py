import logging
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

logger = logging.getLogger(__name__)

# ── Tunable constants ─────────────────────────────────────────────────────────
TFIDF_WEIGHT         = 0.4
EMBEDDING_WEIGHT     = 0.6
SIMILARITY_THRESHOLD = 0.7


def compute_tfidf_score(jd_text: str, resume_text: str) -> float:
    """TF-IDF cosine similarity — keyword overlap between JD and resume."""
    try:
        vec    = TfidfVectorizer(stop_words="english")
        matrix = vec.fit_transform([jd_text, resume_text])
        score  = float(cosine_similarity(matrix[0:1], matrix[1:2])[0][0])
        logger.debug(f"TF-IDF score: {score:.4f}")
        return score
    except Exception as e:
        logger.error(f"TF-IDF error: {e}")
        return 0.0


def compute_embedding_score(jd_embedding: list, resume_embedding: list) -> float:
    """Embedding cosine similarity — semantic meaning."""
    score = float(cosine_similarity([jd_embedding], [resume_embedding])[0][0])
    logger.debug(f"Embedding score: {score:.4f}")
    return score


def compute_hybrid_score(tfidf: float, embedding: float) -> float:
    """Weighted ATS-style blend of both scores."""
    return round(TFIDF_WEIGHT * tfidf + EMBEDDING_WEIGHT * embedding, 4)


def fit_label(score: float) -> str:
    if score >= 0.85:
        return "Strong"
    elif score >= SIMILARITY_THRESHOLD:
        return "Good"
    return "Weak"


def is_match(score: float) -> bool:
    return score >= SIMILARITY_THRESHOLD
