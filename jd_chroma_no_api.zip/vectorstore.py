"""
vectorstore.py — ChromaDB persistence layer.

Chunking strategy:
  ONE resume = ONE document (one chunk).
  The full resume text is stored as-is.
  Pre-computed embeddings are injected directly — Chroma never re-embeds.

Document ID:
  "{sanitised_email}__{sanitised_filename}"
  Email is the unique person key. Two people can share a name, never an email.
  Upserting with the same ID safely overwrites if the same resume is re-uploaded.

Metadata stored per document:
  name, email, filename,
  tfidf_score, embedding_score, hybrid_score,
  matches_jd (int: 1/0 — Chroma doesn't support bool),
  session_id, uploaded_at (ISO-8601 UTC)
"""

import os
import re
import logging
from datetime import datetime, timezone

import chromadb

logger          = logging.getLogger(__name__)
CHROMA_PATH     = os.getenv("CHROMA_PATH", "./chroma_db")
COLLECTION_NAME = "resumes"

_client     = None
_collection = None


def _get_collection():
    global _client, _collection
    if _collection is None:
        logger.info(f"Initialising ChromaDB at '{CHROMA_PATH}'")
        _client     = chromadb.PersistentClient(path=CHROMA_PATH)
        _collection = _client.get_or_create_collection(
            name     = COLLECTION_NAME,
            metadata = {"hnsw:space": "cosine"},
        )
        logger.info(f"ChromaDB ready — {_collection.count()} resume(s) in collection")
    return _collection


def _make_id(email: str, filename: str) -> str:
    safe_email    = re.sub(r"[^a-zA-Z0-9._\-]", "_", email)
    safe_filename = re.sub(r"[^a-zA-Z0-9._\-]", "_", filename)
    return f"{safe_email}__{safe_filename}"


# ── Public API ────────────────────────────────────────────────────────────────

def add_resume(
    *,
    text: str,
    embedding: list,
    name: str,
    email: str,
    filename: str,
    tfidf_score: float,
    embedding_score: float,
    hybrid_score: float,
    matches_jd: bool,
    session_id: str,
) -> str:
    """Upsert one resume as one chunk. Returns the doc_id."""
    col    = _get_collection()
    doc_id = _make_id(email, filename)

    col.upsert(
        ids        = [doc_id],
        documents  = [text],
        embeddings = [embedding],
        metadatas  = [{
            "name":            name,
            "email":           email,
            "filename":        filename,
            "tfidf_score":     round(tfidf_score, 4),
            "embedding_score": round(embedding_score, 4),
            "hybrid_score":    round(hybrid_score, 4),
            "matches_jd":      1 if matches_jd else 0,
            "session_id":      session_id,
            "uploaded_at":     datetime.now(timezone.utc).isoformat(),
        }],
    )
    logger.info(f"Stored → id='{doc_id}'  name='{name}'  email='{email}'")
    return doc_id


def query_resumes(
    query_embedding: list,
    n_results: int = 5,
    only_matched: bool = False,
) -> list[dict]:
    """
    Semantic search over stored resumes.
    Returns candidates sorted by relevance (closest first).
    """
    col   = _get_collection()
    total = col.count()

    if total == 0:
        logger.warning("Collection is empty — no resumes stored yet")
        return []

    where = {"matches_jd": 1} if only_matched else None
    fetch = min(n_results, total)

    try:
        results = col.query(
            query_embeddings = [query_embedding],
            n_results        = fetch,
            where            = where,
            include          = ["metadatas", "distances"],
        )
    except Exception as e:
        logger.error(f"ChromaDB query error: {e}")
        return []

    candidates = []
    for doc_id, meta, dist in zip(
        results["ids"][0],
        results["metadatas"][0],
        results["distances"][0],
    ):
        candidates.append({
            "doc_id":           doc_id,
            "name":             meta.get("name", "Unknown"),
            "email":            meta.get("email", "N/A"),
            "filename":         meta.get("filename", ""),
            "tfidf_score":      meta.get("tfidf_score", 0.0),
            "embedding_score":  meta.get("embedding_score", 0.0),
            "hybrid_score":     meta.get("hybrid_score", 0.0),
            "matches_jd":       bool(meta.get("matches_jd", 0)),
            "search_similarity": round(1 - dist, 4),   # cosine distance → similarity
            "uploaded_at":      meta.get("uploaded_at", ""),
        })

    logger.info(f"Query returned {len(candidates)} candidate(s)")
    return candidates


def get_stats() -> dict:
    col = _get_collection()
    return {
        "total":      col.count(),
        "collection": COLLECTION_NAME,
        "path":       CHROMA_PATH,
    }


def delete_resume(email: str, filename: str) -> bool:
    col    = _get_collection()
    doc_id = _make_id(email, filename)
    try:
        col.delete(ids=[doc_id])
        logger.info(f"Deleted '{doc_id}' from ChromaDB")
        return True
    except Exception as e:
        logger.error(f"Delete failed for '{doc_id}': {e}")
        return False
